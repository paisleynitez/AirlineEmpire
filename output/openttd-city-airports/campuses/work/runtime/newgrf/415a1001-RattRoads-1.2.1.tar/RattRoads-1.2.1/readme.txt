﻿------------------------------------
RattRoads 1.2.1
------------------------------------

RattRoads provides a complete set of 10 roadtypes (6 normal and [optionally]
4 electrified) plus 4 tramtypes. It has support for American or European 
road styles, climate-aware graphics, plus many parameters for customizing to 
your preferred playstyle.


WARNING!
===========================================================================

This NewGRF is only compatible with OpenTTD 13.0 or later!

===========================================================================

------------
Known Issues
------------

 1) Concrete Tramtrack fences sometimes clip when built over foundations
 
 2) Tram tracks don't have proper shading in tunnels

Both issues are due to NRT limitations, but are minor enough to ignore.

----------
Parameters
----------

There are eight parameter settings available:

 1) Roadtype Availability - Year-Dependent (Default) || Always Available
  - This setting affects whether roadtypes are introduced depending on year 
(Default) or if they are always available.

 2) Speed Units - MPH (Default) || KM/H || M\S
  - Choose your preferred units for speed (make sure this is the same as your 
game setting!). This makes sure your speed limits look 'realistic', e.g. no more 
silly 57 km/h speed limits due to unit conversions.
 
 3) Speed Limits - Normal (Default) || Hard || Harder || No Speed Limits
  - This sets the speed limits. The Hard and Harder options offer more restrictive
settings for more challenge, or you can disable speed limits for all roadtypes.

 4) Road Style - American (Default) || European/UK
  - This setting changes the center stripe design which will be displayed, 
switching between American-style yellow stripes or European/UK/Etc. white stripes.

 5) Enable electrified roads - Off (Default) || On
  - If enabled, this option adds electrified versions of 4 roadtypes for use with 
trolleybuses and other catenary-powered road vehicles. These roadtypes require the 
addition of NRT-enabled vehicle sets to be useful, so are disabled by default.

 6) Enable houses alongside Highways - Off (Default) || On
  - By default, houses are forbidden from spawning alongside highways which can cause 
towns to disappear if their roads are replaced by highways. It is highly recommended to 
turn this on for multiplayer servers to prevent griefing from malicious or careless players.

 7) Enable houses alongside Modern Asphalt Road - Off || On (Default)
  - Turn this off to prevent the ugly string of houses from growing alongside the roadway 
outside of cities. Be careful not to convert roads to this type within cities, or the cities 
may disappear!

 8) Enable houses alongside Dirt Road - Off || On (Default)
  - Turn this off to prevent the ugly string of houses from growing alongside the roadway 
outside of cities. Be careful not to convert roads to this type within cities, or the cities 
may disappear!

------------
Speed Limits
------------

type |       easy       |       hard       |       harder     |
---------------------------------------------------------------
       mph / kph / m/s    mph / kph / m/s    mph / kph / m/s
---------------------------------------------------------------
dirt    25 /  40 /  10  |  15 /  20 /  06  |  10 /  15 /  03  |
sett    30 /  50 /  12  |  20 /  30 /  08  |  15 /  20 /  06  |
road    40 /  60 /  17  |  30 /  50 /  12  |  20 /  30 /  08  |
asp1    55 /  90 /  24  |  40 /  60 /  17  |  30 /  50 /  12  |
asp2    85 / 140 /  37  |  60 / 100 /  26  |  50 /  80 /  21  |
hway   inf / inf / inf  |  85 / 140 /  37  |  70 / 110 /  31  |

-----------------
Credits & License
-----------------

Catenary sprites and templates borrowed from Unspooled, by supermop: 
https://www.tt-forums.net/viewtopic.php?t=75986

French translation provided by Pascal Lambert
Tunnel graphics graciously drawn by V453000

All road graphics, OpenGFX sprite modifications, and coding for this NewGRF 
done by Andrew350.


This set uses some sprites from OpenGFX. Most of these graphics were drawn specifically by 
Zephyris, however, all contributors of OpenGFX deserve credit for their work 
on this great set. Thank you!


All of the aforementioned sprites/code are licensed/used under the terms of the 
GNU General Public License version 2, which should be included with this 
NewGRF. See license.txt for details. If for some strange reason you didn't 
recieve a copy of the license with this GRF, it can be found online here: 
http://www.gnu.org/licenses/gpl-2.0.txt


Also a big thanks to everyone involved in keeping OpenTTD going, and a 
special shout-out to the guys behind NRT who made this possible!


--------------------
Obtaining the Source
--------------------

If you feel like looking at the insides of this GRF, or you want to use some 
of the material for your own creation, you can find the source here:

https://www.tt-forums.net/viewtopic.php?f=26&t=76183

And remember everything is licensed under GPLv2, so feel free to use it as
long as you stick to those terms.

---------------------
Questions/Bug Reports
---------------------

If you're having problems, notice a bug, or just want to get a hold of me, 
you can post in the development topic online at tt-forums or PM me, Andrew350:

https://www.tt-forums.net/viewtopic.php?f=26&t=76183

Alternatively I can also be reached on Discord under the name sittinbythefire.