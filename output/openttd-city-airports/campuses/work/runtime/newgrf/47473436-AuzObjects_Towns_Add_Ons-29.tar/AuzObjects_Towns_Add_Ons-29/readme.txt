Auz Town Objects AddOns -- Readme

   Official release & discussion topic
   https://tt-forums.net/viewtopic.php?t=75657

Accommodations, Flags, Police, Ambulance, Service Stations, Country Airports, 
Malls and more. 

Project of: GarryG with help from Quast65 and fridaemon.

: Service Stations
: Servo Extras Overlaps
: Servo Depot Overlay
: Servo Company Buildings
: Servo Extras Single Tiles
: Car Parks for Mall
: Shops for Mall
: Shopping Malls
: Sydney Shop + Cars
: Utility Buildings (Added more water towers)
: Fun Fair
: Country Airport
: Commercials (New)
: Drive-In Theaters (New)
: Accommodation/Schools/City Halls
: Flags
: Parks + Play Grounds (new) (Santa Claus Added)
: Gardens
: Slope Foundations (new)
: Accidents/Emergency (new)
: Ruins and Constructions (new)
: Pedestrian + Bicycle Paths (new)
: Churches & Cemetery (Added Haunted House)

   