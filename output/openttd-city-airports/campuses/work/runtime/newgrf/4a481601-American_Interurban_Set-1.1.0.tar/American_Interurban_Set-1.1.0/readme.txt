Cars:

- Wooden coach motor
- Wooden combine motor
- Wooden freight motor

- Steel coach motor
- Steel combine motor
- Steel freight motor

- Steel high speed coach

- Wooden coach trailer
- Wooden combine trailer
- Wooden freight trailer

- Steel coach trailer
- Steel combine trailer
- Steel freight trailer

- 30 ton steeplecab motor
- 50 ton boxcab motor
- 64 ton steeplecab motor
- 80 ton steeplecab motor


    
Features:
- Motors will have lower running costs when trailing another locomotive
- Motors will not provide power or tractive effort unless the lead engine is another motor
- Interurban motors can only haul other motors or trailers. Steeplecabs can haul anything.
- 2CC paint for all vehicles

Planned features:
- Silverliners, Metroliners, and other American EMUs

Changelog:
    1.0.0
      - Initial Release
      - NEW: Wooden coaches, combines, freight
      - NEW: Motors and trailers
      - NEW: 50' and 60' models

    1.1.0 - Feb 6, 2023
      - NEW: High speed steel coach
      - NEW: Four new freight motors
      - CHANGE: Changed 60' wooden models to steel
      - CHANGE: New graphics for wooden models
      - CHANGE: Lower running costs for MU'd motors
      - CHANGE: Depower motors not led by other motors
      - CHANGE: Interurban motors can only haul other motors or trailers
