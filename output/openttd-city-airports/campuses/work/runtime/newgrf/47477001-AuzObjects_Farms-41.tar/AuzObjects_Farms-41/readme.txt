Auz Farm Objects -- Readme

   Official release & discussion topic
   https://tt-forums.net/viewtopic.php?t=75657

Australian-style objects for farms including farm animals, equipment, 
buildings, landscape tiles, fencing, and overlap object tiles for the 
One-Tile Industry Set (OTIS).

Project of: GarryG 

: Farm Buildings
: Water Supply
: Farm Houses
: Crops
: Trees and Vines
: Farm Machinery
: Animals
: Crop Related
: Livestock Pens
: Farm Bridges
: Grain Storage
: Wagons
: Flower Gardens
: Fence + Track
: OTIS Overlap
: Cattle
: Horses
: Sheep
: Pigs
		
   