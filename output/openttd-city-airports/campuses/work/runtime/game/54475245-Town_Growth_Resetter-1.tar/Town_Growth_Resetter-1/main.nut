class Main extends GSController {
}

function Main::Start() {
	// Perform town growth reset
	local towns = GSTownList();
	GSLog.Info("Resetting town growth rates to their default values");
	for (local town = towns.Begin(); !towns.IsEnd(); town = towns.Next()) {
		GSTown.SetGrowthRate(town, GSTown.TOWN_GROWTH_NORMAL);
	}
	GSLog.Info("  Done.");
	
	// Sleep indefinitely to prevent a crash
	while (true) {
		GSController.Sleep(2147483647)
	}
}

function Main::Save() {
	return { 
		x = 0
	};
}

function Main::Load(version, data) {
}