class Main extends GSInfo
	{
	function GetAuthor()		{ return "James"; }
	function GetName()			{ return "Town Growth Resetter"; }
	function GetDescription() 	{ return "Resets all town growth rates to their default values"; }
	function GetVersion()		{ return 1; }
	function GetDate()			{ return "2022-10-16"; }
	function CreateInstance()	{ return "Main"; }
	function GetShortName()		{ return "TGRE"; }
	function GetAPIVersion()	{ return "12"; }
	function MinVersionToLoad()	{ return 1; }
	function GetUrl()			{ return ""; }

	function GetSettings()
	{
	}

}

RegisterGS(Main());
