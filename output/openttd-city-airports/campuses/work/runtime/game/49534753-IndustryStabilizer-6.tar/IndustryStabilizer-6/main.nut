
/*
 * This file is part of IndustryStabilizer, which is a GameScript for OpenTTD
 *
 * IndustryStabilizer is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License
 *
 * IndustryStabilizer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with IndustryStabilizer; If not, see <http://www.gnu.org/licenses/> or
 * write to the Free Software Foundation, Inc., 51 Franklin Street, 
 * Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */
 
  // Contributors:

class IndustryStabilizer extends GSController 
{
	_isLib_class = import("Industry.ISLib", "", 1);
	_isLib = null;
	constructor()
	{
	this._isLib = _isLib_class();
	// Get executive rights immediately.
	//mode = GSExecMode();
	}
	on_load = false;
	go = true;
	refresh = true;
	first_manage = true;
	function Init();
	}
	

// for testing sendstats
//require("sendstats.nut");	
	
function IndustryStabilizer::Save()
{
	Log.Info("Saving data", Log.LVL_INFO);
	local base_production = _isLib.GetProduction();
	local data = {sv_base = base_production};
	return data;
}

function IndustryStabilizer::Load(version, tbl)
{
	Log.Info("Loading data from savegame made with version " + version + " of the game script", Log.LVL_INFO);
	foreach(key, val in tbl)
	{	
		if(key == "sv_base") 					this._isLib.SetProduction(val);	
	}
	this.on_load = true;
}

//////////////////////////////////// Program entry point
function IndustryStabilizer::Start()
{
	this.Init();
	while (go == true) 
		{
		this.Manage();
		}
		EndGame();
}
//////////////////////////////////// If you want to use IS as part of another script, 
// Call this function on game start, and 
// Connect the load and save functions, and
// Make sure to call my Manage() at least once per day.
function IndustryStabilizer::Start_Lib()
{
	GSGame.Pause();
	this.Init();
	GSGame.Unpause();
}
/////////////////////////////////// Main game loop
function IndustryStabilizer::Manage()
{
	_isLib.SetDebugLevel(GSController.GetSetting("debug_level"));
	_isLib.SetRebuildDiff(GSController.GetSetting("rebuild_diff"));
	_isLib.SetBBPercentage(GSController.GetSetting("bb_percentage"));
	if(GSDate.GetCurrentDate() % GSController.GetSetting("rebuild_speed") == 0 && refresh)
	{
		_isLib.Rebuild();
		refresh = false;
	}
	else
	{
		Sleep(1);
	}
	if(GSDate.GetCurrentDate() % GSController.GetSetting("rebuild_speed") != 0)
	{
		refresh = true;
	}
}

////////////////////////////// Initialization function.
function IndustryStabilizer::Init()
{
	// initialize the library
	this._isLib.SetDebugLevel(GSController.GetSetting("debug_level"));
	this._isLib.SetRebuildDiff(GSController.GetSetting("rebuild_diff"));
	this._isLib.SetBBPercentage(GSController.GetSetting("bb_percentage"));
	this._isLib.Init();
	// we wait a total of 3 months (91 days, or 6734 ticks) to ensure that all industries have finished construction
	Sleep(6734);
	// now set the base construction values.
	_isLib.Reset();
}
// NOTE: Has to be called from the HandleEvents of main.
function IndustryStabilizer::HandleEvents()
{
	while(GSEventController.IsEventWaiting())
	{
		local ev = GSEventController.GetNextEvent();
		
		switch(ev)
		{
		}

		if(ev == null)
			return;
	}
}
