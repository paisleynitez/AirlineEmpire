require ("version.nut")
/*
 * This file is part of IndustryStabilizer, which is a GameScript for OpenTTD
 *
 * CityBuilder is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License
 *
 * CityBuilder is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with CityBuilder; If not, see <http://www.gnu.org/licenses/> or
 * write to the Free Software Foundation, Inc., 51 Franklin Street, 
 * Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */
 
  // Contributors:

class IndustryStabilizer extends GSInfo {
	function GetAuthor()		{ return "Aphid"; }
	function GetName()			{ return "IndustryStabilizer"; }
	function GetDescription() 	{ return "Keeps up map production"; }
	function GetVersion()		{ return SELF_VERSION; }
	function GetDate()			{ return "2013-05-25"; }
	function CreateInstance()	{ return "IndustryStabilizer"; }
	function GetShortName()		{ return "ISGS"; }
	function GetAPIVersion()	{ return "1.3"; }
	function GetUrl()			{ return ""; }
	function GetSettings() {	
		AddSetting({name = "rebuild_speed", description = "Industry Rebuild speed: ", easy_value = 32, medium_value = 32, hard_value = 32, custom_value = 32, flags = 0, min_value = 5, max_value = 480});
		AddSetting({name = "rebuild_diff", description = "Industry rebuild delta size: ", easy_value = 1000, medium_value = 1000, hard_value = 1000, custom_value = 1000, flags = 0, min_value = 100, max_value = 10000, step_size = 100, flags = CONFIG_INGAME});
		AddSetting({name = "bb_percentage", description = "Rebuild below: ", easy_value = 80, medium_value = 80, hard_value = 80, custom_value = 80, flags = CONFIG_INGAME, min_value = 20, max_value = 400, step_size = 5});
		AddSetting({name = "debug_level", description = "Debug level: ", easy_value = 0, medium_value = 0, hard_value = 0, custom_value = 0, flags = CONFIG_INGAME, min_value = 0, max_value = 7});

		}
}
RegisterGS(IndustryStabilizer());