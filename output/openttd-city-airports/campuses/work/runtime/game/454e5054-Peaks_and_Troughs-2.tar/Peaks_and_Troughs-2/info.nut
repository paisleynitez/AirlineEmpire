/*
 * This file is part of MinimalGS, which is a GameScript for OpenTTD
 * Copyright (C) 2012-2013  Leif Linse
 *
 * MinimalGS is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License
 *
 * MinimalGS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MinimalGS; If not, see <http://www.gnu.org/licenses/> or
 * write to the Free Software Foundation, Inc., 51 Franklin Street, 
 * Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */

require("version.nut");

class FMainClass extends GSInfo {
	function GetAuthor()		{ return "Erato"; }
	function GetName()			{ return "Peaks and Troughs v2"; }
	function GetDescription() 	{ return "Varies the travel demand based on the time."; }
	function GetVersion()		{ return SELF_VERSION; }
	function GetDate()			{ return "2024-06-25"; }
	function CreateInstance()	{ return "MainClass"; }
	function GetShortName()		{ return "ENPT"; } // Replace this with your own unique 4 letter string
	function GetAPIVersion()	{ return "1.2"; }
	function GetURL()			{ return "https://www.tt-forums.net/viewtopic.php?f=65&t=87840"; }

	function GetSettings() {
		AddSetting({
			name = "log_level", 
			description = "Debug: Log level (higher = print more)", 
			easy_value = 3, medium_value = 3, hard_value = 3, custom_value = 3, //reminder to set to 1
			flags = CONFIG_INGAME, 
			min_value = 1, max_value = 3});
		AddLabels("log_level", {_1 = "1: Info", _2 = "2: Verbose", _3 = "3: Debug" } );
		AddSetting({
			name = "preset", 
			description = "Preset", easy_value = 2, medium_value = 2, hard_value = 2, custom_value = 2,
			flags = CONFIG_INGAME, 
			min_value = 1, max_value = 5});
		AddLabels("preset", {_1 = "Hyperpeak", _2 = "Equal peaks", _3 = "Japan", _4 = "UK", _5 = "No peaks" } );
		AddSetting({
			name = "base", 
			description = "Passenger rate offset", easy_value = 1, medium_value = 1, hard_value = 1, custom_value = 1,
			flags = CONFIG_INGAME, 
			min_value = -4, max_value = 6});
	}
}

RegisterGS(FMainClass());
