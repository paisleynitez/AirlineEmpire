Peaks and Troughs - A gamescript for time-based travel demand

This gamescript requires JGR patch pack version 0.39.0 or newer.

In normal OpenTTD, the travel demand depends mostly on station
rating. You don't get peak hours, off-peak, nights, etc. Or at least
You didn't. This gamescript adds all travel demand based on real
life data.

For hyperpeaks, data from the Netherlands is used, where everyone
needs to be at their work at a certain time, and no sooner and no
later, creating a massive peak in the mornings. When people go back
home is less important, so the evening peak is a lot lower and wider.

For equal peaks, data from Zürich is used. Both the morning and
evening peaks are quite high and sharp, but neither are as high as the
Dutch hyperpeaks. Because both peaks are approximately equal in size,
this preset might be the easiest on beginners.

For Japan, surprise, surprise, we use data from Japan. Like the
Netherlands, Japan has a hyperpeak in the mornings. Made worse by the
large modal share of public transport. Because of cultural reasons,
many people work a lot of overtime every day, and as a result, the
evening peak is spread across the entire afternoon until the last train.

All passenger distributions were changed so the total amount of
passengers does not depend on the preset, and the total amount of
passengers between 4:00 and 14:59, and between 15:00 and 3:59 is within
5% of eachother.

This gamescript edits the variable "town cargo generation factor".

** Recommendations **
Make use of a NewGRF that changes how station ratings are calculated,
otherwise your morning peaks might be very disappointing, and night
freight might not be feasible.

With daylength 1, a single 24 hour cycle comes down to 4 years. It
might be worth it to increase this significantly, although that does
impact a variety of things like passenger numbers and station rating.

Familiarise yourself with scheduled dispatch.

Don't bother with getting certain trains to do different services based
on the time, unless you know a trick like conditional orders that I don't.
Sure, it's more realistic, but it's often not worth the effort.

Storing trains at rail yards or train stations is more fun than depots.

The hyperpeak in the hyperpeak preset comes out of nowhere, and disappears
as fast as it came into being.
The equal peaks preset has the highest evening peaks, but not by much.
In practice it's the hyperpeak preset, but with a wider and lower
morning peak.
The Japan preset has the highest morning peaks, with the quietest middays
and afternoons, but the busiest late nights.


** Configuration **
Debug: Log level - Increases amount of information in the logs

Preset - Choose which distribution you want

Passenger rate offset - increase or decrease the total amount of
passengers. This goes with 2^x, so setting this to 4, makes it produce
16x as many passengers compared to setting it to 0. It can be set
anywhere between -4 and 6. At night, the production rate might be
below -8 because of this. Because the rate can't be below -8, it will
be set to -8, meaning you might get more night time traffic.
If you have the log-level at 2 or 3, this will show up in the logs.


** Version data **
Version: 1
Date: 2020-10-30


** Credits **
Author: Erato
New GSDate functions: JGR

Data:
Hyperpeaks: 2015 Nederlandse Spoorwegen - NS
Equal peaks: 2010 Zürcher Verkehrsverbund - ZVV
Japan: 2015 Ministry of Land, Infrastructure, Transport and Tourism

Made using Minimal GS.
Minimal GS author: Zuu


** Bugs **
If you have any bugs, please report them to Erato on the TT-forums,
or here:
https://www.tt-forums.net/viewtopic.php?f=65&t=87840