/*
 * This file is part of MinimalGS, which is a GameScript for OpenTTD
 * Copyright (C) 2012-2013  Leif Linse
 *
 * MinimalGS is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License
 *
 * MinimalGS is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with MinimalGS; If not, see <http://www.gnu.org/licenses/> or
 * write to the Free Software Foundation, Inc., 51 Franklin Street, 
 * Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */

/** Import other source code files **/
require("version.nut"); // get SELF_VERSION

//..


class MainClass extends GSController 
{
	_loaded_data = null;
	_loaded_from_version = null;
	_init_done = null;

	/*
	 * This method is called when your GS is constructed.
	 * It is recommended to only do basic initialization of member variables
	 * here.
	 * Many API functions are unavailable from the constructor. Instead do
	 * or call most of your initialization code from MainClass::Init.
	 */
	constructor()
	{
		this._init_done = false;
		this._loaded_data = null;
		this._loaded_from_version = null;
	}
}

/*
 * This method is called by OpenTTD after the constructor, and after calling
 * Load() in case the game was loaded from a save game. You should never
 * return back from this method. (if you do, the script will crash)
 *
 * Start() contains of two main parts. First initialization (which is
 * located in Init), and then the main loop.
 */
function MainClass::Start()
{
	/*
	 * This code initialises Peaks and Throughs, fetching the correct preset and other settings.
	 * Make sure to put in the PnT settings from info.nut into the info.nut of the GS of your choice.
	 * If your GS of choice already has a setting called "preset" or "base", you can change the names
	 * used for the settings as well as what's entered in GetSetting below.
	 */
	GSLog.Info("GameScript Peaks and Troughs loaded");
	
	local preset_setting = MainClass.GetSetting("preset");
	local time_rates = [];
	switch(preset_setting)
	{
		case 1:
			GSLog.Info("Preset: Hyper peak");
			time_rates = [-1.69, -2.80, -5.32, -5.32, -5.32, -2.42, -0.97, 0.00, 1.70, 0.64, 0.15, 0.00, 0.00, 0.00, 0.00, 0.20, 0.68, 1.14, 1.32, 1.14, 0.38, 0.00, -1.00, -1.30];
			break;
		case 2:
			GSLog.Info("Preset: Equal peaks");
			time_rates = [-1.44, -2.58, -5.39, -5.39, -5.39, -2.59, -1.15, 0.79, 1.52, 0.52, 0.07, -0.07, -0.07, -0.07, -0.07, 0.16, 0.37, 0.97, 1.39, 1.21, 0.49, 0.14, -0.75, -1.05];
			break;
		case 3:
			GSLog.Info("Preset: Japan");
			time_rates = [-0.83, -2.07, -5.63, -5.63, -5.63, -2.32, -0.43, 1.13, 1.86, 0.30, -0.31, -0.31, -0.31, -0.31, -0.31, -0.31, 0.07, 0.61, 1.01, 0.87, 0.64, 0.42, 0.15, -0.17];
			break;
		case 4:
			GSLog.Info("Preset: UK");
			time_rates = [-4.76, -6.03, -6.41, -6.44, -5.31, -3.24, -1.41, 0.26, 1.72, 0.87, 0.63, 0.63, 0.63, 0.55, 0.57, 1.61, 0.91, 0.76, 0.56, -0.04, -0.76, -1.44, -1.85, -2.28];
			break;
		case 5:
			GSLog.Info("Preset: No peaks");
			time_rates = [-5.28, -5.28, -5.28, -5.28, -5.28, -5.28, -5.28, 0.72, 0.72, 0.72, 0.72, 0.72, 0.72, 0.72, 0.72, 0.72, 0.72, 0.72, 0.72, 0.72, 0.72, 0.72, -5.28, -5.28];
			break;
		default:
			GSLog.Error("Failed to recognise preset");
	}

	local base_rates = MainClass.GetSetting("base");
	GSLog.Info("Offset: "+base_rates);
	
	local logs = MainClass.GetSetting("log_level");


	this.Init();

	/*
	 * The main game loop for Peaks and Throughs. If you want to slot another GS into PnT, place that GS' main
	 * loop in here. Further instructions are given below.
	 */
	
	if("GetHour" in GSDate) {
		
		GSLog.Info("Correct version of JGR loaded");
		while (true) {
			local loop_start_tick = GSController.GetTick();
			
			//get time
			local tick_scale = GSDate.GetCurrentScaledDateTicks();
			local current_time = GSDate.GetHour(tick_scale)
			//failsafe
			if(current_time >= 24) {
				if (logs != 1) {
					GSLog.Warning("GetHour returned "+current_time);	
					GSLog.Info("Hours set to 0");
				}
				current_time = 0
			}
			
			local prod_rate = (time_rates[current_time]+base_rates)*10
			
			if (prod_rate > 80) {
				if (logs != 1) {
					GSLog.Info("Production rate capped at 8");
				}
				prod_rate = 80;
			}
			if (prod_rate < -80) {
				if (logs != 1) {
					GSLog.Info("Production rate capped at -8");
				}
				prod_rate = -80;
			}
			
			if (logs == 3) {
				GSLog.Info("Time is "+current_time);
				GSLog.Info("Production rate set to "+prod_rate);
			}
			
			GSGameSettings.SetValue("economy.town_cargo_scale_factor", prod_rate.tointeger());
			
			/*
			 * When meshing with a different GS, replace the two lines below with whatever is in the
			 * while(true) loop in MainClass::Start()
			 * As it's written here loops with a frequency of 10 minutes
			 */
			local ticks_used = GSController.GetTick() - loop_start_tick;
			GSController.Sleep(max(1, 10 * 74 - ticks_used));
		}
	} else {
		GSLog.Error("Please update to a newer version of JGR patch pack");
	}
}

/*
 * This method is called during the initialization of your Game Script.
 * As long as you never call Sleep() and the user got a new enough OpenTTD
 * version, all initialization happens while the world generation screen
 * is shown. This means that even in single player, company 0 doesn't yet
 * exist. The benefit of doing initialization in world gen is that commands
 * that alter the game world are much cheaper before the game starts.
 */
function MainClass::Init()
{
	if (this._loaded_data != null) {
		// Copy loaded data from this._loaded_data to this.*
		// or do whatever you like with the loaded data
	} else {
		// construct goals etc.
	}

	// Indicate that all data structures has been initialized/restored.
	this._init_done = true;
	this._loaded_data = null; // the loaded data has no more use now after that _init_done is true.
}