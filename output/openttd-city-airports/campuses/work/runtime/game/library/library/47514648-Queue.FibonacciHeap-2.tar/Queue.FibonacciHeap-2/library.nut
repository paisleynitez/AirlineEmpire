class Fibonacci_Heap extends GSLibrary {
	function GetAuthor()      { return "OpenTTD NoAI Developers Team"; }
	function GetName()        { return "Fibonacci Heap"; }
	function GetShortName()   { return "GQFH"; }
	function GetDescription() { return "An implementation of a Fibonacci Heap for the GameScript framework."; }
	function GetVersion()     { return 2; }
	function GetDate()        { return "2011-12-21"; }
	function CreateInstance() { return "Fibonacci_Heap"; }
	function GetCategory()    { return "Queue"; }
}

RegisterLibrary(Fibonacci_Heap());
