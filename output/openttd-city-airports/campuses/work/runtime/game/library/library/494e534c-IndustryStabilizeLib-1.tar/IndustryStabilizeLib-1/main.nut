
/*
 * This file is part of IndustryStabilizer, which is a GameScript for OpenTTD
 *
 * IndustryStabilizer is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License
 *
 * IndustryStabilizer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with IndustryStabilizer; If not, see <http://www.gnu.org/licenses/> or
 * write to the Free Software Foundation, Inc., 51 Franklin Street, 
 * Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */
 
 // USAGE:
 // Use 'init' to load the library
 // a few months after the game starts, call 'Reset' to set the base production values
 // periodically call 'rebuild' to build new industry. Once every few weeks is sufficient to keep up production on normal maps.
 // 

class ISLib 
{
// class variables
	dbglevel = null; 
	rebuild_diff = null;
	bb_percentage = null;	
	mapsize = null;
	base_production = null;
	industries_producing = null;
	
constructor()
	{
	this.mapsize = GSMap.GetMapSize() / 262144 + 1;
	this.dbglevel = 0;
	this.rebuild_diff = 1000;
	this.bb_percentage = 80;
	// base production value for all cargo.
	this.base_production = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
	// the industries that can produce cargo. 64 32-bit masks of the cargo produced by industry.
	// note: only raw industries are ever spawned by this script.
	this.industries_producing = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
	// Get executive rights immediately.
	//mode = GSExecMode();
	}
	
	
	// Sets/Gets for settings.
	function SetDebugLevel(xx){this.dbglevel = xx;}
	function SetRebuildDiff(xx){this.rebuild_diff = xx;}
	function SetBBPercentage(xx){this.bb_percentage = xx;}	
	function GetDebugLevel(){return this.dbglevel;}
	function GetRebuildDiff(){return this.rebuild_diff;}
	function GetBBPercentage(){return this.bb_percentage;}
	
	// Set/Get the current target values to the production array specified
	function GetProduction(){return base_production;}
	function SetProduction(production_array){base_production = production_array;}
		
	function Init();
	function Reset();
	function Rebuild();
	function CalculateTotalProduction();
	function SelectIndustryType(cargotype);
	
};
// Goal: Initialize with Init. Load all the objects we need in.
// Use 'Reset' to reset the base count values. (In my script do it after ~4months)
// Use 'Rebuild' for a rebuild call. In my script do it every 'N' days where 'N' is the value of the relevant setting.
// Use a debug variable inside of this lib...

// todo: Respond to the relevant options being set to something else in main script by forwarding new values to the Set* functions.

function ISLib::Init()
{
	local Cargolist;
	local IndustryTypeList = GSIndustryTypeList();
	foreach(IType,_ in IndustryTypeList)
		{
		if(dbglevel > 1)
			GSLog.Info("Industry:" + IType);
		if (GSIndustryType.IsRawIndustry(IType))
			{
			Cargolist = GSIndustryType.GetProducedCargo(IType);
			foreach(cargo,_ in Cargolist)
				{
				if(dbglevel > 2)
					GSLog.Info("Cargo" + cargo + ", Industry:" + IType);
				industries_producing[IType] += 1<<cargo;
				}
			}
		}
	if(dbglevel > 0)
		{
		GSLog.Info("IndustryProdList: "); 
		foreach(ind in industries_producing)
			{
			GSLog.Info("P" + ind);
			}
		}
}
// set the target values to what they are now. (calculate the totals...)
function ISLib::Reset()
{
	base_production = this.CalculateTotalProduction();
}



function ISLib::Rebuild()
{
	local current_production = this.CalculateTotalProduction();
	local OldConstr = GSGameSettings.GetValue("construction.raw_industry_construction");
	GSGameSettings.SetValue("construction.raw_industry_construction", 2);
	for(local i = 0; i < 32; ++i)
		{
			local delta = base_production[i] * bb_percentage - current_production[i] * 100;
			if( delta > 0 && base_production[i] > 0)
			{
				// now we want to prospect some extra industry!
				// we want 1 industry per 1000 cargo units difference
				for(local j = 0; j <= delta/(100 * rebuild_diff); ++j)
				{
				local IndustryType = SelectIndustryType(i);
				if(IndustryType != -1) GSIndustryType.ProspectIndustry(IndustryType);
				if(this.dbglevel > 0)
					{
					GSLog.Info("Building A "+GSIndustryType.GetName(IndustryType));
					}
				}
			}
		}
	GSGameSettings.SetValue("construction.raw_industry_construction", OldConstr);
}

function ISLib::CalculateTotalProduction()
{
	local IndustryList = GSIndustryList();
	local current_production = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
	foreach(Industry,_ in IndustryList)
		{
		for(local i = 0; i < 32; ++i)
			{
			current_production[i] += max(GSIndustry.GetLastMonthProduction(Industry, i), 0);
			}
		}
	if(this.dbglevel > 0)
		{
		GSLog.Info("Total Map Production: "); 
		for(local i = 0; i < 32; ++i)
			{
			if(current_production[i] > 0){
				GSLog.Info(GSCargo.GetCargoLabel(i)+": "+current_production[i]+ " | "+base_production[i]);
				}
			}
		}	
	return current_production;
}

function ISLib::SelectIndustryType(cargotype){
// determine which types produce this cargo
local types = [];
for(local i = 0; i < industries_producing.len(); ++i)
	{
	if(industries_producing[i] & (1 << cargotype))
	types.append(i);
	}	
	if(types == []) return -1;
return types[GSBase.RandRange(types.len())];
}

