/* $Id$ */

class ISLib extends GSLibrary {
	function GetAuthor()      { return "Aphid"; }
	function GetName()        { return "IndustryStablilizeLib"; }
	function GetShortName()   { return "INSL"; }
	function GetDescription() { return "Library to stabilize industry production"; }
	function GetVersion()     { return 1; }
	function GetDate()        { return "2012-12-16"; }
	function CreateInstance() { return "ISLib"; }
	function GetCategory()    { return "Industry"; }
}

RegisterLibrary(ISLib());
