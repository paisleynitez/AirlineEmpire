/*
 * This file is part of CityDomination, which is a GameScript for OpenTTD
 * Copyright (C) 2011  Daniel Beal
 *
 * CityDomination is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License
 *
 * CityDomination is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with CityDomination; If not, see <http://www.gnu.org/licenses/> or
 * write to the Free Software Foundation, Inc., 51 Franklin Street, 
 * Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */

class CityDomination extends GSInfo {
	function GetAuthor()		{ return "NullByte"; }
	function GetName()			{ return "CityDomination"; }
	function GetDescription() 	{ return "Companies can dominate cities by having overall greater station ratings"; }
	function GetVersion()		{ return 11; }
	function GetDate()			{ return "2011-12-20"; }
	function CreateInstance()	{ return "CityDomination"; }
	function GetShortName()		{ return "SPCE"; }
	function GetAPIVersion()	{ return "1.2"; }
	function GetUrl()			{ return "http://www.tt-forums.net/viewtopic.php?f=65&t=57886"; }

	function GetSettings() {
		// My regards to LSky for introducing this idea
		AddSetting({name = "population_measure", description = "Set population goals along with the specific town domination goals", easy_value = 1, medium_value = 1, hard_value = 1, custom_value = 1, flags = CONFIG_BOOLEAN});
		AddSetting({name = "population_amount", description = "The interval between population goals.  This has no effect if population goals are not enabled", easy_value = 5000, medium_value = 10000, hard_value = 15000, custom_value = 5000, step_size = 1000, flags = 0, min_value = 500, max_value = 50000 });
		AddSetting({name = "goals_per_company", description = "The number of goals each company should have", easy_value = 3, medium_value = 3, hard_value = 3, custom_value = 3, flags = 0, min_value = 0, max_value = 10});
		AddSetting({name = "pending_days", description = "The number of days before a company offically dominates the town", easy_value = 5, medium_value = 5, hard_value = 5, custom_value = 5, flags = CONFIG_INGAME, min_value = 0, max_value = 365});
		AddSetting({name = "log_level", description = "Debug: Log level (higher = print more)", easy_value = 2, medium_value = 2, hard_value = 2, custom_value = 2, flags = CONFIG_INGAME, min_value = 1, max_value = 3});
	}
}

RegisterGS(CityDomination());
