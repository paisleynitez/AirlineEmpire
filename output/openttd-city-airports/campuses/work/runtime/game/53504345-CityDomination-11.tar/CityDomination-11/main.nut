/*
 * This file is part of City Domination, which is a GameScript for OpenTTD
 * Copyright (C) 2011  Daniel Beal
 *
 * City Domination is free software; you can redistribute it and/or modify it 
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 of the License
 *
 * City Domination is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with City Domination; If not, see <http://www.gnu.org/licenses/> or
 * write to the Free Software Foundation, Inc., 51 Franklin Street, 
 * Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */

import("util.superlib", "SuperLib", 24);
Helper <- SuperLib.Helper;
Tile <- SuperLib.Tile;
Log <- SuperLib.Log;

scriptInstance <- null;

/**
 * A base goal class.
 */
class Goal
{
	id = null; ///< The ID for the goal
	company = null; ///< The company with the goal
	constructor(company) {
		this.company = company;
	}
	
	/**
	 * Ensures the goal is valid
	 * @return if the goal was valid or not
	 */
	function VerifyGoal();
	
	/**
	 * Exports a table which can be saved and reloaded
	 * @return table with the field varialbes in table form
	 */
	function ExportTable();
	
	/**
	 * Virtual function to be called when the goal should get a chance to operate
	 * @return if the goal is completed
	 */
	function ManageGoal();
}

function Goal::VerifyGoal()
{
	return GSGoal.IsValidGoal(id);
}

function Goal::ExportTable()
{
	return {
		id = this.id,
		company = this.company
	}
}

function Goal::ManageGoal()
{
	// Pure virtual - do nothing (but return)
	return false;
}

/**
 * A goal to dominate a town
 */
class GoalTown extends Goal
{
	town = null; ///< Town which should be dominated
	time = null; ///< Variable holding the time the user started dominating the town
	constructor(company, town, id = null, time = null) {
		if(GSCompany.ResolveCompanyID(company) == GSCompany.COMPANY_INVALID) Log.Warning("COMPANY IS INVALID");
		if(id == null) this.id = GSGoal.New(company, GSText(GSText.STR_GOAL_TOWN, town), GSGoal.GT_TOWN, town);
		else this.id = id;
		this.company = company;
		this.town = town;
		if(!time) this.time = 0;
		else this.time = time;
		if(id == null) GSNews.Create(GSNews.NT_GENERAL, GSText(GSText.STR_NEW_GOAL_TOWN, town), company);
	}
	function ExportTable();
	/**
	 * Checks to see if the player has dominated the town
	 * @return if the goal was completed or not
	 */
	function ManageGoal();
}

function GoalTown::ManageGoal()
{
	local gtown = null;
	foreach(townitem in scriptInstance.towns) {
		if(town == townitem.id) {
			gtown = townitem;
			break;
		}
	}
	if(!gtown) {
		Log.Warning("Could not find town for goal!");
		return { finished = false };
	}
	if(!GSTown.IsValidTown(gtown.id)) {
		Log.Warning("Could not find town for goal: " + GSTown.GetName(town.id));
		return { finished = false };
	}
	// Find out the company has taken the town
	if(time == 0 && company == gtown.owner) {
		// Start the clock!
		Log.Info("Started clock for goal in company " + GSCompany.GetName(company) + " in town " + GSTown.GetName(town));
		time = GSDate.GetCurrentDate();
	}
	// Find out if they were not able to keep the town long enough
	else if(time != 0 && company != gtown.owner) {
		// Reset the clock
		Log.Info("Reset clock for goal in company " + GSCompany.GetName(company) + " in town " + GSTown.GetName(town));
		time = 0;
	}
	return { finished = time != 0 && time < GSDate.GetCurrentDate() - 90, populationGoal = false };
}

function GoalTown::ExportTable()
{
	return {
		id = this.id,
		company = this.company,
		town = this.town,
		time = this.time,
		populationGoal = false
	};
}

/**
 * Goal for dominating a total amount of population
 */
class GoalPopulation extends Goal
{
	population = null; ///< The amount of population to dominate
	constructor(company, population, id = null) {
		if(id == null) this.id = GSGoal.New(company, GSText(GSText.STR_GOAL_POPULATION, population), GSGoal.GT_NONE, 0);
		else this.id = id;
		this.company = company;
		this.population = population;
		if(id == null) GSNews.Create(GSNews.NT_GENERAL, GSText(GSText.STR_NEW_GOAL_POPULATION, population), company);
	}
	function ExportTable();
	
	/**
	 * Finds out if the dominated population is achieved
	 * @return if the goal is completed or not
	 */
	function ManageGoal();
}

function GoalPopulation::ExportTable()
{
	return {
		id = this.id,
		company = this.company,
		population = this.population
		populationGoal = true
	};
}

function GoalPopulation::ManageGoal()
{
	local dominatedPopulation = 0;
	foreach(town in scriptInstance.towns) {
		if(town.owner == company) dominatedPopulation += GSTown.GetPopulation(town.id);
	}
	return { finished = dominatedPopulation > population, populationGoal = true };
}

/**
 * Custom town object optimized for CityDomination
 */
class Town
{
	id = null; ///< The town ID
	owner = null; ///< The company which owns it
	pendingTime = null; ///< Used for changing owners after a set time so the owner has to really "dominate" the town for good
	pendingOwner = null; ///< the possible new owner
	constructor(id, owner) {
		this.id = id;
		this.owner = owner;
	}
	
	/**
	 * Changes the owner of the town, and creates relevant media to advertise it
	 * @param the company ID of the new owner
	 */
	function ChangeOwner(newOwner);
	
	/**
	 * Lazy loop function to verify that the pending owner still "owns" the town, and changes the owner if neccissary
	 * @param The currently dominating company
	 */
	function CheckPendingOwner(dominatingCompany);
	
	/**
	 * Function which handles the town growth speed
	 */
	function CheckGrowthSpeed();
	
	/**
	 * Updates the sign displaying who owns the town
	 */
	function UpdateSign();
}

function Town::ChangeOwner(newOwner)
{
	if(owner != GSCompany.COMPANY_INVALID) {
		GSNews.Create(GSNews.NT_ECONOMY, GSText(GSText.STR_TOWN_TAKEN_OVER, id, newOwner), owner);
		GSNews.Create(GSNews.NT_ECONOMY, GSText(GSText.STR_YOU_TOOK_OVER, id, owner), newOwner);
	}
	owner = newOwner;
	GSTown.ExpandTown(id, 2);
	Log.Info(GSCompany.GetName(newOwner) + " took over " + GSTown.GetName(id), Log.LVL_SUB_DECISIONS);
}

function Town::CheckPendingOwner(dominatingCompany)
{
	if(owner == GSCompany.COMPANY_INVALID) {
		ChangeOwner(dominatingCompany);
		return;
	}
	if(dominatingCompany != owner && dominatingCompany != pendingOwner) {
		// Start the timer
		Log.Info(GSCompany.GetName(dominatingCompany) + " became the pending owner of " + GSTown.GetName(id));
		pendingOwner = dominatingCompany;
		pendingTime = GSDate.GetCurrentDate();
	}
	if(pendingOwner && pendingOwner != GSCompany.COMPANY_INVALID && pendingTime < GSDate.GetCurrentDate() - GSController.GetSetting("pending_days")) {
		ChangeOwner(pendingOwner);
		pendingOwner = GSCompany.COMPANY_INVALID;
		pendingTime = 0;
	}
}

function Town::CheckGrowthSpeed()
{
	local rate = 365;
	local companies = [];
	local stations = GSStationList(GSStation.STATION_ANY);
	stations.Valuate(GSStation.GetNearestTown);
	stations.KeepValue(id);
	stations.Valuate(GSStation.GetOwner);
	foreach(station, value in stations) {
		local existing = false;
		foreach(company in companies) if(value == company) existing = true;
		if(!existing) rate -= 80;
		else rate -= 30;
	}
	if(rate < 31) rate = 31
	GSTown.SetGrowthRate(id, rate);
}

function Town::UpdateSign()
{
	Log.Info("Updating town owners for town " + GSTown.GetName(id), Log.LVL_SUB_DECISIONS);
	if(GSCompany.ResolveCompanyID(owner) == GSCompany.COMPANY_INVALID) Helper.SetSign(Tile.GetTileRelative(GSTown.GetLocation(id), 1, 1), GSText(GSText.STR_NOT_OWNED), true);
	else Helper.SetSign(Tile.GetTileRelative(GSTown.GetLocation(id), 1, 1), GSText(GSText.STR_OWNER, owner), true);
}

/**
 * Custom Company object optimized for CityDomination
 */
class Company
{
	id = null;
	hq = null;
	hqsign = null;
	constructor(id, hq, hqsign = null) {
		this.id = id;
		this.hq = hq;
	}
	
	/**
	 * Exports the object for saving.  Can be reloaded into an identical company object
	 */
	function ExportTable();
}

function Company::ExportTable()
{
	return {
		id = this.id,
		hq = this.hq,
		hqsign = this.hqsign
	};
}

/**
 * Main class for CityDomination, required for any OpenTTD GameScript/AI
 */
class CityDomination extends GSController
{
	lastYear = null; ///< The year last known so we can know when the year changes
	newCompanies = null; ///< Companies which have not yet created a HQ for goals
	companies = null; ///< A list of 'registered' companies for goals and have built an HQ
	towns = null; ///< A list of all the towns on the map as a Town object
	goals = null; ///< A list of all the goals currently in the game
	save = null; ///< The data loaded in the "save" function
	saveversion = null; ///< The version of the data save data in the "save" variable
	constructor() {
		newCompanies = GSList();
		companies = [];
		towns = [];
		goals = [];
		save = false;
	}
	/**
	 * The entering function, where everything starts.  Holds the main loop
	 */
	function Start();
	
	/**
	 * Function called when the game is saving
	 */
	function Save();
	
	/**
	 * Function called when data is available for loading in a savegame
	 * @param the version of the CityDomination the data was saved
	 * @param a table of the data saved in the game
	 */
	function Load(version, data);
	
	/**
	 * Function called in the main loop to check GSEvent quene and other things
	 */
	function CheckEvents();
	
	/**
	 * Scans the map and determines the owners for each town
	 */
	function CheckMap();
	
	/**
	 * Allows the goals to run and checks if they are completed
	 */
	function CheckGoals();
	
	/**
	 * Creates a new goal and adds it to the list of goals
	 * @param The company to create the goal for
	 * @param Whether its a population goal or not (defaults false)
	 */
	function CreateGoal(company);
	
	/**
	 * Updates the town signs for all towns
	 */
	function UpdateTownOwners();
}

function CityDomination::Start()
{
	scriptInstance = this;
	if(save) {
		// Load the goals
		if(saveversion == 2) {
			foreach(goal in save) goals.append(Goal(goal.company, goal.town, goal.id, goal.time));
		}
		if(saveversion >= 3) {
			foreach(goal in save["goals"]) {
				if(!goal.populationGoal) goals.append(GoalTown(goal.company, goal.town, goal.id, goal.time));
				else goals.append(GoalPopulation(goal.company, goal.population, goal.id));
			}
			foreach(company in save["companies"]) companies.append(Company(company.id, company.hq, company.hqsign));
		}
	}
	local townlist = GSTownList();
	foreach(town, _ in townlist) {
		towns.append(Town(town, GSCompany.COMPANY_INVALID));
		// Slow down the growth rate a little
		GSTown.SetGrowthRate(town, GSTown.GetGrowthRate(town) + 20);
	}
	UpdateTownOwners();
	lastYear = GSDate.GetYear(GSDate.GetCurrentDate());
	Log.Info("City Domination Started!", Log.LVL_SUB_DECISIONS);
	GSController.Sleep(1);
	local loop = 0;
	while(true) {
		CheckEvents();
		CheckMap();
		CheckGoals();
		if(loop % 10 == 0) {
			Log.Info("Adjusting town growth speeds...", Log.LVL_SUB_DECISIONS);
			foreach(town in towns) town.CheckGrowthSpeed();	
		}
		GSController.Sleep(10);
		loop++;
	}
}

function CityDomination::CheckEvents()
{
	// I consider HQ movement an event :)
	foreach(company in companies) {
		if(company.hq != GSCompany.GetCompanyHQ(company.id)) {
			Log.Info(GSCompany.GetName(company.id) + " moved or destroyed their HQ.", Log.LVL_SUB_DECISIONS);
			// Right now we have to find the sign manually...
			local signlist = GSSignList();
			signlist.Valuate(GSSign.GetLocation);
			signlist.KeepValue(company.hq);
			GSSign.RemoveSign(signlist.Begin());
			company.hq = GSCompany.GetCompanyHQ(company.id);
			company.hqsign = null;
		}
		if(company.hq == GSMap.TILE_INVALID && GSCompany.GetCompanyHQ(company.id) != GSMap.TILE_INVALID) company.hq = GSCompany.GetCompanyHQ(company.id);
	}
	// General events
	while(GSEventController.IsEventWaiting()) {
		local event = GSEventController.GetNextEvent();
		if(event == null) continue;
		local eventType = event.GetEventType();
		if(eventType == GSEvent.ET_COMPANY_BANKRUPT) {
			// If the company owned towns, set them to no owner, and delete the company from the company pool
			Log.Info("Found bankrupt company!", Log.LVL_SUB_DECISIONS);
			local deadcompany = GSEventCompanyBankrupt.Convert(event);
			foreach(town in towns) {
				if(town.owner == deadcompany.GetCompanyID()) town.owner = GSCompany.COMPANY_INVALID;
			}
			for(local i = 0;i < companies.len();i++) {
				if(companies[i].id == deadcompany.GetCompanyID()) {
					companies.remove(i);
					break;
				}
			}
		}
		if(eventType == GSEvent.ET_COMPANY_MERGER) {
			local merge = GSEventCompanyMerger.Convert(event);
			Log.Info("Caught company merge of company " + merge.GetOldCompanyID() + " into " + GSCompany.GetName(merge.GetNewCompanyID()), Log.LVL_SUB_DECISIONS);
			// Due to some issues I am having with the merge, I will reset all town owners to GSCompany.COMPANY_INVALID and reload
			foreach(town in towns) town.owner = GSCompany.COMPANY_INVALID;
			
			for(local i = 0;i < companies.len();i++) {
				if(companies[i].id == merge.GetOldCompanyID()) {
					companies.remove(i);
					break;
				}
			}
		}
		if(eventType == GSEvent.ET_COMPANY_NEW) {
			Log.Info("Found new company!", Log.LVL_SUB_DECISIONS);
			local newcompany = GSEventCompanyNew.Convert(event);
			GSNews.Create(GSNews.NT_GENERAL, GSText(GSText.STR_PLACE_HQ), newcompany.GetCompanyID());
			newCompanies.AddItem(newcompany.GetCompanyID(),0);
		}
		if(eventType == GSEvent.ET_TOWN_FOUNDED) {
			Log.Info("Found new town!", Log.LVL_SUB_DECISIONS);
			local newTown = GSEventTownFounded.Convert(event);
			towns.append(Town(newTown.GetTownID(), GSCompany.COMPANY_INVALID))
			UpdateTownOwners();
		}
	}
}

function CityDomination::CheckMap()
{
	foreach(company, _ in newCompanies) {
		if(GSCompany.GetCompanyHQ(company) != GSMap.TILE_INVALID) {
			Log.Info("Company built HQ: " + GSCompany.GetName(company), Log.LVL_SUB_DECISIONS);
			if(GSController.GetSetting("population_measure") != 1) Helper.SetSign(GSCompany.GetCompanyHQ(company), GSText(GSText.STR_DOMINATED_TOWNS, 0), true);
			else Helper.SetSign(GSCompany.GetCompanyHQ(company), GSText(GSText.STR_DOMINATED_POP, 0), true);
			GSNews.Create(GSNews.NT_GENERAL, GSText(GSText.STR_NEW_HQ, company, GSTile.GetClosestTown(GSCompany.GetCompanyHQ(company))), GSCompany.COMPANY_INVALID);
			for(local i = 0;i < GSController.GetSetting("goals_per_company");i++) CreateGoal(company);
			// If we have population goals, add that goal as well
			if(GSController.GetSetting("population_measure") == 1) CreateGoal(company, true);
			companies.append(Company(company, GSCompany.GetCompanyHQ(company)));
			newCompanies.RemoveItem(company);
		}
	}
	local competitors = GSList();
	foreach(company in companies) competitors.AddItem(company.id, 0);
	local loop = 0;
	foreach(town in towns) {
		// Get a list of all stations inside the town
		local tilelist = Tile.GetTownTiles(town.id);
		tilelist.Valuate(GSTile.IsStationTile);
		tilelist.KeepValue(1);
		local stationlist = GSList();
		foreach(tile, _ in tilelist) {
			if(!stationlist.HasItem(GSStation.GetStationID(tile))) {
				if(GSStation.GetNearestTown(GSStation.GetStationID(tile)) != town.id) {
					Log.Info("Excluding station " + GSStation.GetName(GSStation.GetStationID(tile)) + " because it is not offically part of the town!");
					continue;
				}
				Log.Info("Adding station " + GSStation.GetName(GSStation.GetStationID(tile)));
				local stationScore = 0;
				foreach(cargo, _ in GSCargoList()) {
					if(GSStation.GetCargoWaiting(GSStation.GetStationID(tile), cargo) > 0) stationScore += GSStation.GetCargoRating(GSStation.GetStationID(tile), cargo);
				}
				if(stationScore > 0) stationlist.AddItem(GSStation.GetStationID(tile), stationScore);
			}
		}
		local companylist = competitors;
		if(stationlist.IsEmpty()) {
//			Log.Info("Town " + GSTown.GetName(town) + " has no stations in it");
			continue;
		}
		// Now get a list of companies get a score for each of them
		local companylist = GSList();
		for(local competitor = GSCompany.COMPANY_FIRST;competitor <= GSCompany.COMPANY_LAST;competitor++) {
			if(GSCompany.ResolveCompanyID(competitor) != GSCompany.COMPANY_INVALID) companylist.AddItem(competitor,0);
		}
		foreach(station, score in stationlist) {
			companylist.SetValue(GSStation.GetOwner(station), companylist.GetValue(GSStation.GetOwner(station)) + score);
		}
		// Finally, determine the company that should own the town
		companylist.Sort(GSList.SORT_BY_VALUE, false);
		local oldowner = town.owner;
		Log.Info("Old Owner: " + GSCompany.GetName(oldowner));
		town.CheckPendingOwner(companylist.Begin());
		//if(oldowner == GSCompany.COMPANY_INVALID && oldowner != companylist.Begin()) town.ChangeOwner(companylist.Begin());
		Log.Info("New Owner: " + GSCompany.GetName(companylist.Begin()));
		if(oldowner != town.owner) town.UpdateSign();
		Log.Info("Winning Company: " + GSCompany.GetName(town.owner));
		if(GSController.GetSetting("population_measure") == 1) competitors.SetValue(town.owner, competitors.GetValue(town.owner) + GSTown.GetPopulation(town.id));
		else competitors.SetValue(town.owner, competitors.GetValue(town.owner) + 1);
		if(loop % 5 == 0) GSController.Sleep(1);
		loop++;
	}
	// Replace the HQ Domination numbers
	foreach(company, score in competitors) {
		if(GSCompany.GetCompanyHQ(company) != GSMap.TILE_INVALID) {
			if(GSController.GetSetting("population_measure") != 1) Helper.SetSign(GSCompany.GetCompanyHQ(company), GSText(GSText.STR_DOMINATED_TOWNS, score), true);
			else Helper.SetSign(GSCompany.GetCompanyHQ(company), GSText(GSText.STR_DOMINATED_POP, score), true);
		}
	}
	// If its a new year, share the results
	if(lastYear < GSDate.GetYear(GSDate.GetCurrentDate()) && !competitors.IsEmpty()) {
		local bestcompany = null;
		local bestscore = 0;
		local tie = false;
		foreach(company, score in competitors) {
			if(score > bestscore) {
				bestscore = score;
				bestcompany = company;
				tie = false;
			}
			else if(score == bestscore) {
				tie = true;
			}
		}
		if(!tie && GSController.GetSetting("population_measure") != 1) GSNews.Create(GSNews.NT_GENERAL, GSText(GSText.STR_YEAR_RESULTS_TOWN, bestcompany, bestscore), GSCompany.COMPANY_INVALID);
		else if(!tie) GSNews.Create(GSNews.NT_GENERAL, GSText(GSText.STR_YEAR_RESULTS_POP, bestcompany, bestscore), GSCompany.COMPANY_INVALID);
		else GSNews.Create(GSNews.NT_GENERAL, GSText(GSText.STR_YEAR_TIE, bestscore), GSCompany.COMPANY_INVALID);
		lastYear = GSDate.GetYear(GSDate.GetCurrentDate());
		// Disclose the results on the admin port
		foreach(company, score in competitors) GSAdmin.Send({ action = "population", company = company, population = score });
	}
}

function CityDomination::CheckGoals()
{
	Log.Info("Checking goals...");
	for(local i = 0;i < goals.len();i++) {
		local result = goals[i].ManageGoal();
		if(result.finished == true) {
			// Do some good stuff :)
			Log.Info(GSCompany.GetName(goals[i].company) + " completed their goal!", Log.LVL_SUB_DECISIONS);
			if(!result.populationGoal) GSNews.Create(GSNews.NT_GENERAL, GSText(GSText.STR_COMPLETED_GOAL, goals[i].town), goals[i].company);
			else GSNews.Create(GSNews.NT_GENERAL, GSText(GSText.STR_COMPLETED_POP_GOAL, goals[i].population), goals[i].company);
			if(!result.populationGoal) GSTown.ExpandTown(goals[i].town, 8);
			// Create a new goal
			CreateGoal(goals[i].company, result.populationGoal);
			// Remove the old goal
			GSGoal.Remove(goals[i].id);
			goals.remove(i);
			i--;
		}
	}
}

function CityDomination::CreateGoal(company, populationGoal = false)
{
	Log.Info("Creating new goal for company " + GSCompany.GetName(company), Log.LVL_SUB_DECISIONS);
	if(!populationGoal) {
		// Put various towns as a factor for choosing their next town to occupy:
		local townlist = GSTownList();
		// (currently, only) The Comany HQ (so that the company grows in a circle around its hq
		// Remove the towns they already own
		foreach(town in towns) {
			if(company == town.owner) townlist.RemoveItem(town.id);
		}
		if(townlist.IsEmpty()) {
			Log.Warning("Either the company " + GSCompany.GetName(company) + " has taken over the entire map, or there is something wrong with the goalfinding.");
			return;
		}
		townlist.Valuate(GSTown.GetDistanceManhattanToTile, GSCompany.GetCompanyHQ(company));
		townlist.Sort(GSList.SORT_BY_VALUE, true);
		local chosenTown = townlist.Begin();
		// Ensure no duplicate goals
		foreach(goal in goals) {
			if(goal instanceof GoalPopulation) continue;
			while(company == goal.company && chosenTown == goal.town) {
				if(townlist.IsEnd()) {
					Log.Info("No more towns to get a goal from!");
					return;
				}
				chosenTown = townlist.Next();
			}
		}
		// Finish by creating the goal
		goals.append(GoalTown(company, chosenTown));
		if(!goals[goals.len() - 1].VerifyGoal()) {
			Log.Warning("Could not create goal: " + GSError.GetLastErrorString());
			goals.remove(goals.len() - 1);
		}
	}
	else {
		local townlist = GSList();
		foreach(town in towns) {
			if(company == town.owner) townlist.AddItem(town.id, 0);
		}
		townlist.Valuate(GSTown.GetPopulation);
		local totalPopulation = 0;
		foreach(town, population in townlist) totalPopulation += population;
		// Find the lowest multiplier of 5000 above the total population of all the dominated towns
		local populationGoal = 0;
		while(populationGoal <= totalPopulation) populationGoal += GSController.GetSetting("population_amount");
		Log.Info("The new population goal for " + GSCompany.GetName(company) + " is " + populationGoal);
		goals.append(GoalPopulation(company, populationGoal));
		if(!goals[goals.len() - 1].VerifyGoal) {
			Log.Warning("Could not create goal: " + GSError.GetLastErrorString());
			goals.remove(goals.len() - 1);
		}
	}
}

function CityDomination::UpdateTownOwners()
{
	Log.Info("Updating town owners for each town...");
	foreach(atown in towns) atown.UpdateSign();
	GSController.Sleep(5);
}

function CityDomination::Save()
{
	Log.Info("Saving game...");
	local data = {};
	local goalstable = {};
	local companiestable = {};
	foreach(goal in goals) goalstable[goal.id] <- goal.ExportTable();
	foreach(company in companies) companiestable[company.id] <- company.ExportTable();
	data["goals"] <- goalstable;
	data["companies"] <- companiestable;
	return data;
}

function CityDomination::Load(version, data)
{
	Log.Info("Loading from save: Version " + version);
	if(version == 1) {
		Log.Warning("Version 1 did not support save/load, your goals will be reset (even though they are still there)");
		return;
	}
	if(version == 2) {
		Log.Warning("Version 2 did not save company data.  you may experience stray signs!");
	}
	if(version > 8) {
		Log.Warning("You are using a older version of CityDomination than that in the save.  Please use the content downloader to upgrade to the latest version.");
		Log.Warning("Otherwise, CityDomination has the POTENTIAL of CRASHING");
	}
	save = data;
	saveversion = version;
}
