/*
 * This file is part of Renewed City Growth, a GameScript for OpenTTD.
 * Copyright (C) 2013-2014 keoz
 *
 * It's free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the
 * Free Software Foundation, version 2 of the License.
 *
 */


require("version.nut");

class MainClass extends GSInfo
	{
	function GetAuthor()		{ return "keoz"; }
	function GetName()		{ return "Renewed City Growth"; }
	function GetShortName() 	{ return "RECG"; }
	function GetDescription()	{ return "A city growth script. Towns require various cargo delivery to grow. Supporting Baseset, FIRS and ECS industries. See the readme.txt for detailed description."; }
	function GetURL()		{ return "http://www.tt-forums.net/viewtopic.php?f=65&t=69827"; }
	function GetVersion()		{ return SELF_VERSION; }
	function GetDate()		{ return "2014-12-31"; }
	function GetAPIVersion()	{ return "1.4"; }
	function MinVersionToLoad()	{ return 1; }
	function CreateInstance()	{ return "MainClass"; }
	function GetSettings() {

		AddSetting({ name = "industry_NewGRF",
				description = "Which industry set is being used?",
				easy_value = 1,
				medium_value = 1,
				hard_value = 1,
				custom_value = 1,
				flags = CONFIG_NONE, min_value = 1, max_value = 11 });
		AddLabels("industry_NewGRF", { _1 = "Baseset: Temperate",
					_2 = "Baseset: Arctic",
					_3 = "Baseset: Tropical",
					_4 = "Baseset: Toyland",
					_5 = "FIRS: Firs economy",
					_6 = "FIRS: Temperate basic",
					_7 = "FIRS: Arctic basic",
					_8 = "FIRS: Tropic Basic",
					_9 = "FIRS: Hearth of Darkness",
					_10 = "ECS: All Vectors",
					_11 = "YETI (v5350)" });

		AddSetting({ name = "goal_scale_factor",
				description = "Difficulty level (easy = 60, normal = 100, hard = 140)",
				easy_value = 60,
				medium_value = 100,
				hard_value = 140,
				custom_value = 100,
				flags = CONFIG_INGAME, min_value = 1, max_value = 1000, step_size = 20 });

		AddSetting({ name = "merge_cat_2_3",
				description = "Merge categories 2 (food) and 3 (goods) into one (see readme.txt)",
				easy_value = 0,
				medium_value = 0,
				hard_value = 0,
				custom_value = 0,
				flags = CONFIG_BOOLEAN });

		AddSetting({ name = "merge_cat_4_5",
				description = "Merge categories 4 (raw ind.) and 5 (trans. ind.) into one (see readme.txt)",
				easy_value = 0,
				medium_value = 0,
				hard_value = 0,
				custom_value = 0,
				flags = CONFIG_BOOLEAN });

		AddSetting({ name = "use_town_sign",
				description = "Show growth rate text under town names",
				easy_value = 1,
				medium_value = 1,
				hard_value = 1,
				custom_value = 1,
				flags = CONFIG_BOOLEAN });

		AddSetting({ name = "log_level",
				description = "Debug: Log level (higher = print more)",
				easy_value = 1,
				medium_value = 1,
				hard_value = 1,
				custom_value = 1,
				flags = CONFIG_INGAME, min_value = 1, max_value = 3 });
		AddLabels("log_level", { _1 = "1: Info", _2 = "2: (unused)", _3 = "3: Debug" });

		AddSetting({ name = "town_growth_factor",
				description = "Expert setting: town growth factor",
				easy_value = 100,
				medium_value = 100,
				hard_value = 100,
				custom_value = 100,
				flags = CONFIG_INGAME, min_value = 20, max_value = 1000, step_size = 20 });

		AddSetting({ name = "supply_impacting_part",
				description = "Expert setting: minimum supply percentage for TGR growth",
				easy_value = 50,
				medium_value = 50,
				hard_value = 50,
				custom_value = 50,
				flags = CONFIG_INGAME, min_value = 0, max_value = 100, step_size = 5 });

		AddSetting({ name = "exponentiality_factor",
				description = "Expert setting: TGR growth exponentiality factor",
				easy_value = 3,
				medium_value = 3,
				hard_value = 3,
				custom_value = 3,
				flags = CONFIG_INGAME, min_value = 1, max_value = 5 });

		AddSetting({ name = "lowest_town_growth_rate",
				description = "Expert setting: lowest TGR if requirements are not meet",
				easy_value = 10000,
				medium_value = 10000,
				hard_value = 10000,
				custom_value = 10000,
				flags = CONFIG_INGAME, min_value = 1000, max_value = 30000, step_size = 1000 });
	}
}

RegisterGS(MainClass());
