require("Vehicle.nut");

class AllVehicles extends GSVehicleList
{
	function GetFirstVehicle();
	function GetNextVehicle();
}

function AllVehicles::GetFirstVehicle()
{
	return Vehicle(this.Begin())
}

function AllVehicles::GetNextVehicle()
{
	return Vehicle(this.Next())
}