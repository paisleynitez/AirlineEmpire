class Payment
{
	fromCompanyID = null;
	toCompanyID = null;
	
	constructor(fromCompanyID, toCompanyID)
    {
        this.fromCompanyID = fromCompanyID
		this.toCompanyID = toCompanyID;
    }
	
	function Pay();
}

function Payment::Pay(amount)
{
	if (amount > 0)
	{
		GSCompany.ChangeBankBalance(this.fromCompanyID, -amount, GSCompany.EXPENSES_ROADVEH_RUN);
		GSCompany.ChangeBankBalance(this.toCompanyID, amount, GSCompany.EXPENSES_OTHER);
	}
}