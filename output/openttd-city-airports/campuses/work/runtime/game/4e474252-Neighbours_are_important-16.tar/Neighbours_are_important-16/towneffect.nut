
g_town_effect_cache <- null;

class TownEffect
{
	static function GetCargoList();
}

/*static*/ function TownEffect::GetCargoList() {
	if (g_town_effect_cache != null) return g_town_effect_cache;

	// At first level result is a table where town effect is used as key
	// As value for each key, there is an array with all cargo IDs that
	// correspond to this town effect.
	local result = {};
	foreach (cargo_id, cargo_value in GSCargoList()) {
		local cargo_lbl = GSCargo.GetCargoLabel(cargo_id)
		local cargo_ef = GSCargo.GetTownEffect(cargo_id)
		if (cargo_ef > 0) {
			if (!result.rawin(cargo_ef)) {
				result.rawset(cargo_ef, []);
			}
			result.rawget(cargo_ef).append(cargo_id);
		}
	}

	// If we have TE_PASSENGERS, sort the cargo list so that
	// the passenger cargo is first in the list.
	//
	// This make sure we display 'passengers' and not 'tourists'
	// when ECS is used in the stockpile info which only display
	// the first cargo name.
	if (result.rawin(GSCargo.TE_PASSENGERS)) {
		result.rawget(GSCargo.TE_PASSENGERS).sort(PassengerSorter);
	}

	Log.Info("Town effect cargos:", Log.LVL_SUB_DECISIONS);
	foreach(te, cargo_list in result) {
		local s = "";
		foreach(cargo in cargo_list) {
			if (s != "") s += ", ";
			s += GSCargo.GetCargoLabel(cargo);
		}

		Log.Info(GetTownEffectString(te) + ": " + s, Log.LVL_SUB_DECISIONS);
	}
			
	// Store result in a global cache var as the result will not change through the game
	// (unless someone changes NewGRFs in the game - which is not supported)
	g_town_effect_cache = result;
		
	return result;
}

/*
 * Sort method for Squerrel Array .sort that
 * put the Passenger cargo first in the array.
 */
function PassengerSorter(a, b)
{
	// First sort the Passenger cargo first
	local PAX = Helper.GetPAXCargo();
	if (a == PAX && b != PAX) return -1;
	if (a != PAX && b == PAX) return 1;
	// second, lowest cargo ID first
	if (a>b) return 1;
	if (b>a) return -1;
	return 0;
}

function GetTownEffectString(town_effect)
{
	switch(town_effect){
		case(1): return "TE_PASSENGERS";
		case(2): return "TE_MAIL";
		case(3): return "TE_GOODS";
		case(4): return "TE_WATER";
		case(5): return "TE_FOOD";
	}

	return "[Unknown Town Effect]";
}
