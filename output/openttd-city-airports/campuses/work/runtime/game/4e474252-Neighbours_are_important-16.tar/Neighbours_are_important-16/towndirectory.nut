MAX_NEIGHBOUR_DISTANCE <- 100;

class TownDirectory {

	sector_list = null;

	x_sector_count = null; // N sectors in x direction
	y_sector_count = null;

	static SECTOR_SIZE = 256; // Determined on a 2048x2048 map with 'high' town density.

	constructor() {
		this.BuildSectors();
	}

	// Call this one when a new town has been created in a running game
	function AddTown(town_id);

	function GetSector(town_id); // returns sector table
	function GetNeighbours(town_id, sector); // sector = sector table

	/*
	 * Creates an array with a GoalTown instance for each town in the game.
	 */
	function CreateGoalTownList();
};

// Helper method that add a town_id to a sector if it match the sector
// area.
function AddToSectorIfMatch(town_id, town_x, town_y, towns, neighbour_towns, 
		sector_x_min, sector_y_min, sector_x_max, sector_y_max,
		sector_neighbourhood_x_min, sector_neighbourhood_y_min, sector_neighbourhood_x_max, 
		sector_neighbourhood_y_max) {
	if (town_x >= sector_neighbourhood_x_min &&
			town_x < sector_neighbourhood_x_max &&
			town_y >= sector_neighbourhood_y_min &&
			town_y < sector_neighbourhood_y_max) {

		// Inside sector or sector neighbourhood

		// Inside sector?
		if (town_x >= sector_x_min && town_x < sector_x_max &&
				town_y >= sector_y_min && town_y < sector_y_max) {
			towns.append(town_id);
		} else {
			// Inside sector neighbourhood
			neighbour_towns.append(town_id);
		}
	}
}

function TownDirectory::BuildSectors()
{
	this.sector_list = [];

	this.x_sector_count = max(1, GSMap.GetMapSizeX() / TownDirectory.SECTOR_SIZE);
	this.y_sector_count = max(1, GSMap.GetMapSizeY() / TownDirectory.SECTOR_SIZE);

	// Prepare an array over all towns with their x+y coordinate pre-calculated
	local all_towns = GSTownList();
	all_towns.Valuate(GSTown.GetLocation);
	local all_towns_array = [];
	foreach(town_id, town_tile in all_towns) {
		all_towns_array.append({
				id=town_id,
				x=GSMap.GetTileX(town_tile),
				y=GSMap.GetTileY(town_tile),
		});
	}

	// The array order will be [(0,0), (1,0), (2,0), (0,1), ..] with (x,y)
	local map_size_x = GSMap.GetMapSizeX();
	local map_size_y = GSMap.GetMapSizeY();
	for (local y = 0; y < map_size_y; y += TownDirectory.SECTOR_SIZE) {
		for (local x = 0; x < map_size_x; x += TownDirectory.SECTOR_SIZE) {
			// This local variable bloat is to not need to access data from the sector table
			// as doing this in the inner loop have significant impact on performance.
			local sector_x_min = x
			local sector_y_min = y
			local sector_x_max = min(x + TownDirectory.SECTOR_SIZE, map_size_x);
			local sector_y_max = min(y + TownDirectory.SECTOR_SIZE, map_size_y);

			local sector_neighbourhood_x_min = sector_x_min - MAX_NEIGHBOUR_DISTANCE;
			local sector_neighbourhood_y_min = sector_y_min - MAX_NEIGHBOUR_DISTANCE;
			local sector_neighbourhood_x_max = sector_x_max + MAX_NEIGHBOUR_DISTANCE;
			local sector_neighbourhood_y_max = sector_y_max + MAX_NEIGHBOUR_DISTANCE;

			local towns = [];
			local neighbour_towns = []; // Towns outside min/max x/y, but near enough to be considered as neighbours to towns in the sector

			// Populate town lists
			foreach(town in all_towns_array) {
				AddToSectorIfMatch(town.id, town.x, town.y, 
						towns, 
						neighbour_towns, 
						sector_x_min, 
						sector_y_min, 
						sector_x_max, 
						sector_y_max,
						sector_neighbourhood_x_min, 
						sector_neighbourhood_y_min, 
						sector_neighbourhood_x_max, 
						sector_neighbourhood_y_max
				);
			}

			local sector = {
				towns = towns,
				neighbour_towns = neighbour_towns
				x_min = sector_x_min,
				y_min = sector_y_min,
				x_max = sector_x_max,
				y_max = sector_y_max
			}

			this.sector_list.append(sector);
		}
	}
}

function TownDirectory::AddTown(town_id)
{
	local town_tile = GSTown.GetLocation(town_id);
	local town_x = GSMap.GetTileX(town_tile);
	local town_y = GSMap.GetTileY(town_tile);

	foreach(sector in this.sector_list) {
		local sector_x_min = sector.x_min ;
		local sector_y_min = sector.y_min;
		local sector_x_max = sector.x_max;
		local sector_y_max = sector.y_max;

		local sector_neighbourhood_x_min = sector_x_min - MAX_NEIGHBOUR_DISTANCE;
		local sector_neighbourhood_y_min = sector_y_min - MAX_NEIGHBOUR_DISTANCE;
		local sector_neighbourhood_x_max = sector_x_max + MAX_NEIGHBOUR_DISTANCE;
		local sector_neighbourhood_y_max = sector_y_max + MAX_NEIGHBOUR_DISTANCE;

		AddToSectorIfMatch(town_id, town_x, town_y, 
				sector.towns, 
				sector.neighbour_towns, 
				sector_x_min, 
				sector_y_min, 
				sector_x_max, 
				sector_y_max,
				sector_neighbourhood_x_min, 
				sector_neighbourhood_y_min, 
				sector_neighbourhood_x_max, 
				sector_neighbourhood_y_max
		);
	}
}

function TownDirectory::GetSector(town_id)
{
	local town_tile = GSTown.GetLocation(town_id);
	local town_x = GSMap.GetTileX(town_tile);
	local town_y = GSMap.GetTileY(town_tile);
	local x_sector = town_x / TownDirectory.SECTOR_SIZE;
	local y_sector = town_y / TownDirectory.SECTOR_SIZE;
	local index = x_sector + y_sector * this.x_sector_count;

	return this.sector_list[index];
}

function TownDistSorter(a, b) { 
	return a.dist == b.dist? 1 : (a.dist > b.dist ? 1 : -1); 
}
function TownDirectory::GetNeighbours(town_id, sector)
{
	local min_dist = MAX_NEIGHBOUR_DISTANCE + 1;
	local neighbour_count = 0;
	local neighbours = [];
	local n_list = [null, null, null];
	local town_tile = GSTown.GetLocation(town_id);

	local towns = sector.towns;
	local neighbour_towns = sector.neighbour_towns;

	// Loop over all towns in sector.towns and sector.neighbour_towns
	local n_towns = sector.towns.len();
	local n_neighbour_towns = sector.neighbour_towns.len();
	for (local i = 0; i < n_towns + n_neighbour_towns; i++) {
		// t = loop town id
		local t = i < n_towns ? towns[i] : neighbour_towns[i-n_towns];

		/* Skip town if it is the same as town_id */
		if (t == town_id) continue;

		/* Add towns with distance less than 100 tiles to neighbor list */
		local distance = GSMap.DistanceManhattan(town_tile, GSTown.GetLocation(t));

		if (distance > MAX_NEIGHBOUR_DISTANCE) continue;
		//if (neighbour_count >= 3 && distance > min_dist) continue;

		/* Check if new distance is shortest, second shortest or third shortest distance.
		 * If the following is generalized into a loop, that uses quite a bit more CPU time.
		 */
		if (n_list[0] == null || distance < n_list[0].dist) {
			n_list[2] = n_list[1];
			n_list[1] = n_list[0];
			n_list[0] = { id = t, dist = distance };

		} else if (n_list[1] == null || distance < n_list[1].dist) {
			n_list[2] = n_list[1];
			n_list[1] = { id = t, dist = distance };
		} else if (n_list[2] == null || distance < n_list[2].dist) {
			n_list[2] = { id = t, dist = distance };
		}
	}

	/* Sort by distance */
	//neighbours.sort(TownDistSorter);
	for (local i = 0; i < 3; i++) {
		if (n_list[i] != null) {
			neighbours.append(n_list[i]);
		}
	}

	Log.Info(GSTown.GetName(town_id) + " neighbours:", Log.LVL_DEBUG);
	if (Log.IsLevelAccepted(Log.LVL_DEBUG)) {
		foreach(t in neighbours) {
			Log.Info("  " + GSTown.GetName(t.id) + "  " + t.dist);
		}
	}

	return neighbours;
}

function TownDirectory::CreateGoalTownList()
{
	local result = [];

	/* Make a squirrel array of all towns.
	 * For each town, an instance of GoalTown is created
	 * to store the data related to that town
	 */

	local neigh_ticks = 0;
	local town_ticks = 0;

	/* Loop over sectors in town_directory */
	local loop_start = GSController.GetTick();
	foreach (sector in this.sector_list) {
		foreach (t in sector.towns) {
			local start = GSController.GetTick();
			local neighbours = this.GetNeighbours(t, sector);
			local end = GSController.GetTick();
			neigh_ticks += (end - start);

			Log.Info("Create GoalTown for " + GSTown.GetName(t), Log.LVL_SUB_DECISIONS);
			local start = GSController.GetTick();
			local town = GoalTown(t, neighbours);
			result.append(town);
			local end = GSController.GetTick();
			town_ticks += (end - start);
		}
	}
	local loop_end = GSController.GetTick();
	local other_ticks = (loop_end - loop_start) - neigh_ticks - town_ticks;

	if (OUTPUT_TICKS) Log.Info("CreateGoalTownList ticks used for neighbours: " + neigh_ticks + ", GoalTown constructor: " + town_ticks + ", other: " + other_ticks, Log.LVL_INFO);

	return result;
}
