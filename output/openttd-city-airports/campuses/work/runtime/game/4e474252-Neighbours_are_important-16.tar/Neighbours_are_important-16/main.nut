require("version.nut");
require("town.nut");
require("towndirectory.nut");
require("towneffect.nut");
require("storybook.nut");

/* Import SuperLib for GameScript */
import("util.superlib", "SuperLib", 38);
Result <- SuperLib.Result;
Log <- SuperLib.Log;
Helper <- SuperLib.Helper;
ScoreList <- SuperLib.ScoreList;
Tile <- SuperLib.Tile;
Direction <- SuperLib.Direction;
Town <- SuperLib.Town;
Industry <- SuperLib.Industry;
Story <- SuperLib.Story;

OUTPUT_TICKS <- false;

class MainClass extends GSController 
{
	constructor()
	{
	}

	towns = null;
	town_directory = null; // helper for dividing large maps into sectors to reduce the computation time when looking for neighbours.
	story_book_manager = null;
	last_date = 0;
	current_year = 0;
	last_master_switch_value = true;

	loaded_data = null; // assigned when loading a save game
	loaded_from_version = null; // assigned when loading a save game
	town_save_data = null; // after each manage this will point to the last save data.

	init_done = false; // set to true when initialization of data structures has been fully completed.

	function Save();
	function Load(version, data);
}

function MainClass::Start()
{
	local start_tick = GSController.GetTick();
	Log.Info("Start tick: " + start_tick, Log.LVL_DEBUG);
	Log.Info("INIT SCRIPT ... (can take a while on large maps)", Log.LVL_INFO);
	this.Init();
	local setup_duration = GSController.GetTick() - start_tick;

	Log.Info("INIT DONE", Log.LVL_INFO);
	Log.Info("init took " + setup_duration + " ticks", Log.LVL_INFO);
	Log.Info("", Log.LVL_INFO);

	Log.Info("Happy playing", Log.LVL_INFO);

	GSController.Sleep(1);

	this.ShowUpdateNotice();

	while (true) {
		this.HandleMasterSwitch();
		this.HandleEvents();
		if(this.last_master_switch_value == true)
		{
			this.ManageTowns();
			this.story_book_manager.ManageContent();
		}

		this.Sleep(60);
	}
}

function MainClass::Init()
{
	this.last_master_switch_value = GSController.GetSetting("master_switch") == 1;
	if(this.last_master_switch_value)
	{
		GSGameSettings.SetValue("economy.town_growth_rate", 2);
		GSGameSettings.SetValue("economy.fund_buildings", 0);
	}
	this.last_date = GSDate.GetCurrentDate();
	this.current_year = GSDate.GetYear(this.last_date);
	Log.Info("Init: master switch: " + this.last_master_switch_value, Log.LVL_INFO);

	Log.Info("Divide map into sectors ...", Log.LVL_INFO);
	local start = GSController.GetTick();
	this.town_directory = TownDirectory();
	local end = GSController.GetTick();
	if (OUTPUT_TICKS) Log.Info("Map sectors created (ticks used: " + (end-start) + ")", Log.LVL_INFO);
	this.towns = [];

	// Was any data loaded?
	if (this.loaded_data != null) {
		// Load towns
		if (this.loaded_data.rawin("towns")) {
			Log.Info("Loading saved town data ...", Log.LVL_INFO);

			local towns = this.loaded_data.rawget("towns");
			foreach (town_table in towns) {
				this.towns.append(GoalTown.CreateFromTable(town_table, this.loaded_from_version));
			}
		}
		// Load last manage date
		if (this.loaded_data.rawin("last_date")) {
			this.last_date = this.loaded_data.rawget("last_date");
			this.current_year = GSDate.GetYear(this.last_date);
		}
	}

	// If no towns were loaded, create the town list from scratch
	if (this.towns.len() == 0) {
		Log.Info("Create town list ...", Log.LVL_INFO);
		this.towns = this.town_directory.CreateGoalTownList();
	}


	// Store the save data for all towns in an array (which will then get updates after each town
	// manage)
	local start = GSController.GetTick();
	this.town_save_data = this.GetTownSaveData();
	local end = GSController.GetTick();
	if (OUTPUT_TICKS) Log.Info("Ticks used to create initial save data: " + (end-start), Log.LVL_INFO);

	// Set initial time the towns will grow
	local start = GSController.GetTick();
	Log.Info("Setup town goals ...", Log.LVL_INFO);
	InitalizeManageTimers(this.towns, this.last_master_switch_value);
	local end = GSController.GetTick();
	if (OUTPUT_TICKS) Log.Info("Ticks used to initialize manage timers: " + (end-start), Log.LVL_INFO);

	// The story book is the first initialization part that needs correct return values from DoCommands.
	if (Helper.HasWorldGenBug()) {
		GSController.Sleep(1); // Force world gen to end
	}

	// Initialize story book manager
	local start = GSController.GetTick();
	if (this.loaded_data != null && this.loaded_data.rawin("story_book")) {
		this.story_book_manager = StoryBookManager.CreateFromTable(this.loaded_data.story_book, this.loaded_from_version);
	} else {
		this.story_book_manager = StoryBookManager();
	}
	// refresh/create book
	this.story_book_manager.ManageContent();
	local end = GSController.GetTick();
	if (OUTPUT_TICKS) Log.Info("Ticks used by StoryBook init: " + (end-start), Log.LVL_INFO);

	this.init_done = true;
	this.loaded_data = null; // loaded data is no longer useful
}

// Non-class function
function InitalizeManageTimers(town_list, manage = true)
{
	foreach (town in town_list) {
		town.check_timer = GSBase.RandRange(20) + 10;
		if (manage)
			town.ManageTown();
	}
}

function MainClass::HandleEvents()
{
	if (GSEventController.IsEventWaiting())
	{
		local ev = GSEventController.GetNextEvent();

		if (ev == null)
			return;

		
		local ev_type = ev.GetEventType();
		if(ev_type == GSEvent.ET_TOWN_FOUNDED)
		{
			// Trigger updating of town list directly when the
			// town event is received. (eg. don't wait for the
			// periodical town update)
			if(this.last_master_switch_value == true)
				this.CheckForNewTowns();
		}
	}
}

function MainClass::CheckForNewTowns()
{
	Log.Info("Check for new towns", Log.LVL_SUB_DECISIONS);

	// Do our town-list have fewer towns than the game?
	local world_towns = GSTownList();
	Log.Info("town list: " + this.towns.len() + " towns. World: " + world_towns.Count() + " towns", Log.LVL_DEBUG);
	if (this.towns.len() < world_towns.Count())
	{
		// Create a GSList with all towns that we have
		local have_towns = GSList();
		foreach (town in this.towns)
		{
			have_towns.AddItem(town.id, 0);
		}
		
		// Reduce the world list of towns with those that we already have
		world_towns.RemoveList(have_towns);

		// Add the remaining towns to our list
		// Also, keep a list of newly added towns
		local new_towns = [];
		foreach (town_id, _ in world_towns)
		{
			Log.Info("New town " + GSTown.GetName(town_id) + " detected. Add it", Log.LVL_INFO);
			this.town_directory.AddTown(town_id);
			local sector = this.town_directory.GetSector(town_id);
			local neighbours = this.town_directory.GetNeighbours(town_id, sector);
			local town = GoalTown(town_id, neighbours);
			this.towns.append(town);
			new_towns.append(town);
		}

		// Perform an initial manage of the new towns
		InitalizeManageTimers(new_towns, true);
	}
}

function MainClass::ManageTowns()
{
	local date = GSDate.GetCurrentDate();
	local diff = date - this.last_date;
	this.last_date = date;

	if (diff == 0) return;

	this.CheckForNewTowns();

	foreach (town in this.towns) {

		town.check_timer -= diff;

		if (town.check_timer <= 0) {
			town.check_timer = town.check_timer + GSBase.RandRange(20) + 10;
			town.ManageTown();
			/* Update this.town_save_data with the latest town data */
			if (this.town_save_data != null) {
				this.town_save_data.rawset(town.id, town.SaveToTable());
			}
		}
	}
}

function MainClass::HandleMasterSwitch()
{
	local new_value = GSController.GetSetting("master_switch") == 1;

	// Have the master switch changed its value?
	if (new_value != this.last_master_switch_value)
	{
		Log.Info("Detected change of master switch", Log.LVL_INFO);

		if (new_value == true)
		{
			// GS have been re-enabled
			Log.Info("> Enable Neighbours are important :-)", Log.LVL_INFO);

			GSGameSettings.SetValue("economy.town_growth_rate", 2);
			GSGameSettings.SetValue("economy.fund_buildings", 0);

			// Any NewTown events that occurred while the GS have been disabled
			// have been thrown away. So check if there are any new towns.
			this.CheckForNewTowns();

			this.ManageTowns();
			Log.Info("> The script have been re-enabled :-)", Log.LVL_INFO);
		}
		else
		{
			// GS have been disabled - restore default town growth
			Log.Info("> Disable Neighbours are important", Log.LVL_INFO);

			// Show a notice to allow some time for towns to restore
			for (local companyID = GSCompany.COMPANY_FIRST; companyID <= GSCompany.COMPANY_LAST; companyID++) {
				if (GSCompany.ResolveCompanyID(companyID) != GSCompany.COMPANY_INVALID) {
					GSGoal.Question(1, companyID, GSText(GSText.STR_NOTICE_DISABLING_TAKES_TIME), GSGoal.QT_WARNING, GSGoal.BUTTON_CLOSE);
				}
			}

			foreach (town in this.towns) {
				town.Restore();
			}

			GSGameSettings.SetValue("economy.town_growth_rate", 2);
			GSGameSettings.SetValue("economy.fund_buildings", 1);

			// Refresh the story book (when the master switch is off, this 
			// doesn't happen automatically in the main-loop)
			this.story_book_manager.ManageContent();

			Log.Info("> Completed restoring towns + game settings.", Log.LVL_INFO);
			if (!("TOWN_GROWTH_NONE" in GSTown)) {
				Log.Info("> Note: Now allow time for OpenTTD to manage all towns", Log.LVL_INFO);
			}	
		}

		this.last_master_switch_value = new_value;
	}
}

function MainClass::ShowUpdateNotice()
{
	// Don't show update notices for new games
	if(this.loaded_data == null) return;

	if(this.loaded_from_version < 6)
	{
		// Loaded from a version that used the old legacy method for
		// comparing town sizes. Version 1-5 didn't have the setting
		// introduced in version 6, so the game have now defaulted to
		// the new method. Display a notice to players about this.
		for (local companyID = GSCompany.COMPANY_FIRST; companyID <= GSCompany.COMPANY_LAST; companyID++) {
			if (GSCompany.ResolveCompanyID(companyID) != GSCompany.COMPANY_INVALID) {
				GSGoal.Question(0, companyID, GSText(GSText.STR_NOTICE_NEW_TOWN_COMPARE_METHOD), GSGoal.QT_WARNING, GSGoal.BUTTON_CLOSE);
			}
		}
	}

}

function MainClass::GetTownSaveData()
{
	local towns = {};
	foreach (town_id, town in this.towns) {
		towns.rawset(town_id, town.SaveToTable());
	}

	return towns;
}

function MainClass::Save()
{
	Log.Info("Saving ... ", Log.LVL_SUB_DECISIONS);

	if(!this.init_done) {
		return this.loaded_data != null ? this.loaded_data : {};
	}
	
	// Use already prepared town save data if it exists
	local towns = null;
	if (this.town_save_data == null || this.town_save_data.len() == 0) {
		towns = this.GetTownSaveData();
	} else {
		towns = this.town_save_data;
	}

	local data = {
		towns = towns,
		last_date = this.last_date,
		story_book = this.story_book_manager.SaveToTable()
	};

	return data;
}

function MainClass::Load(version, table)
{
	Log.Info("Loading..", Log.LVL_INFO);
	Log.Info("Previously saved with Game Script version " + version, Log.LVL_INFO);

	if(version > SELF_VERSION)
	{
		Log.Warning("Warning: Loading from a newer version of Neighbours are important", Log.LVL_INFO);
	}
	this.loaded_data = table;
	this.loaded_from_version = version;
}
