

class StoryBookManager
{
	state = null; // setting state at last check
	page_id = null;
	page_element_id = null;

	constructor()
	{
		this.state = null;
		this.page_id = -1;
		this.page_element_id = -1;
	}

	// Public:
	function ManageContent(); // checks if the content is up to date. If not, update the content text.
	function UpdateBook();

	static function CreateFromTable(table, version);
	function SaveToTable();

	// Private:
	function GetStrParams();
	function InitBook();
	static function GetEnabledSettingArray();
	static function GetAboutText();
	function GetState();
}

// Returns an array with true/false for if the 'enabled' string should be used
/*static*/ function StoryBookManager::GetEnabledSettingArray()
{
	local result = [
			GSController.GetSetting("master_switch") == 1,
			GSController.GetSetting("enable_neighbours") == 1,
			GSController.GetSetting("congestion_policy") != CONGESTION_DONT_CARE,
			GSController.GetSetting("enable_stockpiles") == 1,
			GSController.GetSetting("town_growth_toggle_method") != GROWTH_TOGGLE_DISABLED,
	];

	// If the master switch is off, then mark all features as disabled
	if (GSController.GetSetting("master_switch") != 1) {
		for (local i = 0; i < result.len(); i++) {
			result[i] = false;
		}
	}

	return result;
}
/*static*/ function StoryBookManager::GetAboutText()
{
	local text = GSText(GSText.STR_PAGE1_TEXT);
	local settings_array = StoryBookManager.GetEnabledSettingArray();
	foreach(s in settings_array) {
		text.AddParam(GSText(s ? GSText.STR_ENABLED : GSText.STR_DISABLED));
	}
	return text;
}
function StoryBookManager::InitBook()
{
	if (!Story.IsStoryBookAvailable()) return;

	// page 1 - about NAI
	{
		local title = GSText(GSText.STR_PAGE1_TITLE);
		local text = StoryBookManager.GetAboutText();

		local result = Story.NewStoryPage2(GSCompany.COMPANY_INVALID, title, [
				[GSStoryPage.SPET_TEXT, 0, text],
		]);
		this.page_id = result[0];
		this.page_element_id = result.len() >= 2 ? result[1] : GSStoryPage.STORY_PAGE_ELEMENT_INVALID;
	}

	// page 2 - stockpile key
	{
		local title = GSText(GSText.STR_PAGE2_TITLE);
		local content = [
			[GSStoryPage.SPET_TEXT, 0, GSText(GSText.STR_PAGE2_1_TEXT)]
		];

		local town_effects = TownEffect.GetCargoList();
		foreach(te, cargo_list in town_effects) {
			local town_window_bits = 1 << cargo_list[0];
			local full_bits = 0;
			foreach(cargo_id in cargo_list) {
				full_bits = full_bits | (1 << cargo_id);
			}
			content.append(
					[GSStoryPage.SPET_TEXT, 0, GSText(GSText.STR_PAGE2_2_TEXT_STOCKPILE, town_window_bits, full_bits)]
			);
		}

		content.append(
				[GSStoryPage.SPET_TEXT, 0, GSText(GSText.STR_PAGE2_3_STAR)]
		);
		
		Story.NewStoryPage(GSCompany.COMPANY_INVALID, title, content);
	}
}

function StoryBookManager::ManageContent()
{
	if (!Story.IsStoryBookAvailable()) return;

	// Create the book pages if they don't exist
	if (!GSStoryPage.IsValidStoryPage(this.page_id)) {
		this.InitBook();
	}

	// Refresh the about page if any setting change
	local curr_state = StoryBookManager.GetState();
	if (curr_state != this.state) {
		this.UpdateBook();
		this.state = curr_state;
	}
}

function StoryBookManager::UpdateBook()
{
	Log.Info("Update story book", Log.LVL_INFO);
	if (GSStoryPage.IsValidStoryPageElement(this.page_element_id)) {
		Log.Info("Update about page", Log.LVL_DEBUG);
		local text = StoryBookManager.GetAboutText();
		GSStoryPage.UpdateElement(this.page_element_id, 0, text);
	}
}

function StoryBookManager::GetState()
{
	local result = 0;
	local settings = StoryBookManager.GetEnabledSettingArray();
	for(local i = 0; i < settings.len(); i++) {
		result += (settings[i] ? 1 : 0) << i;
	}

	return result;
}

/*static*/ function StoryBookManager::CreateFromTable(table, version)
{
	local manager = StoryBookManager();
	manager.page_id = table.page_id;
	manager.page_element_id = table.page_element_id;

	return manager;
}

function StoryBookManager::SaveToTable()
{
	return {
		page_id = this.page_id,
		page_element_id = this.page_element_id,
	};
}
