
/*
 * For each town in the game, an instance of this class is created.
 * It holds the data related to a specific town.
 */
class GoalTown
{
	id = 0;
	check_timer = 0;
	neighbors = null;
	is_congested = null;
	growth_manually_disabled = null;
	congestion_goal_id = null;
	prev_text_status = null;
	// Stockpile Storage map
	cargo_stockpile = null;
	cargo_delivery_goals = null;
	cargo_last_delivery = null;
	town_effect_cargos = null;

	// Variable used to see if this is a running managed game, or was just started [first month] or loaded from save
	prev_cycle = null;

	static CYCLE_MANAGE = 0;
	static CYCLE_INIT_NEW_GAME = 1;
	static CYCLE_INIT_FROM_SAVE = 2;


	// pre_calculated_neighbors should be a list of up to 3 elements containing neighbors of
	// the town.
	constructor(town_id, pre_calculated_neighbors)
	{
		this.id = town_id;
		this.neighbors = pre_calculated_neighbors;
		Log.Info(GSTown.GetName(town_id) + " neighbours start:");
		foreach(t in this.neighbors) {
			Log.Info("  " + GSTown.GetName(t.id) + "  " + t.dist);
		}
		this.is_congested = false;
		this.growth_manually_disabled = false;
		this.congestion_goal_id = -1;
		this.prev_text_status = 0;
		this.prev_cycle = GoalTown.CYCLE_INIT_NEW_GAME;

		this.town_effect_cargos = TownEffect.GetCargoList();
		this.cargo_stockpile = {};
		this.cargo_stockpile.rawset(GSCargo.TE_PASSENGERS,0);
		this.cargo_stockpile.rawset(GSCargo.TE_FOOD,0);
		this.cargo_stockpile.rawset(GSCargo.TE_WATER,0);
		this.cargo_stockpile.rawset(GSCargo.TE_MAIL,0);
		this.cargo_stockpile.rawset(GSCargo.TE_GOODS,0);

		this.cargo_delivery_goals = {};
		this.cargo_delivery_goals.rawset(GSCargo.TE_PASSENGERS,0);
		this.cargo_delivery_goals.rawset(GSCargo.TE_FOOD,0);
		this.cargo_delivery_goals.rawset(GSCargo.TE_WATER,0);
		this.cargo_delivery_goals.rawset(GSCargo.TE_MAIL,0);
		this.cargo_delivery_goals.rawset(GSCargo.TE_GOODS,0);

		this.cargo_last_delivery = {};
		this.cargo_last_delivery.rawset(GSCargo.TE_PASSENGERS,0);
		this.cargo_last_delivery.rawset(GSCargo.TE_FOOD,0);
		this.cargo_last_delivery.rawset(GSCargo.TE_WATER,0);
		this.cargo_last_delivery.rawset(GSCargo.TE_MAIL,0);
		this.cargo_last_delivery.rawset(GSCargo.TE_GOODS,0);

		this.UpdateTownText();
	}

	function ManageTown(); // <-- Main function to process town

	// private functions for town management
	function UpdateTownText();
	function SetGrowthRate();
	function SetGoal();
	function CheckCongestion();
	function Restore(); // restore town to OpenTTD default growth

	// functions for saving and loading the game
	function SaveToTable();
	static function CreateFromTable(table, version);
}

function GoalTown::ManageTown()
{
	this.CheckCongestion();
	this.SetGrowthRate();
	this.SetGoal();

	// When stockpiles is disabled, the town text doesn't include any 
	// goal specific content and does in general not need to be updated 
	// more than when the game starts. However, the enable_neighbours 
	// setting can be changed in-game, and in the case that it is changed, 
	// the text needs to be updated. A update is also needed if 
	// this.growth_manually_disabled change value.
	local curr_text_status = GSController.GetSetting("enable_neighbours") +
			2 * (this.growth_manually_disabled? 1 : 0) +
			4 * (GSController.GetSetting("enable_stockpiles")? 1 : 0);
	if (this.prev_text_status != curr_text_status || GSController.GetSetting("enable_stockpiles"))
	{
		this.prev_text_status = curr_text_status;
		this.UpdateTownText();
	}

	this.prev_cycle = GoalTown.CYCLE_MANAGE;
}

function GoalTown::UpdateTownText()
{
	Log.Info(GSTown.GetName(this.id) + " - UpdateTownText");
	// If neighbours are enabled, display the town neighbours in the town window
	local text = "";
	if (this.growth_manually_disabled == true)
	{
		text = GSText(GSText.STR_TOWN_GROWTH_MANUALLY_DISABLED);
	}
	else if (GSController.GetSetting("enable_neighbours") == 1)
	{
		text = GSText(GSText.STR_0_NEIGHBORS_TOWN_GUI + this.neighbors.len());
		foreach(n in this.neighbors)
		{
			text.AddParam(n.id);
		}
		if (this.neighbors.len() > 0)
		{
			// Add info-text that informs players how neighbours work only if there are at least one neighbour.
			text.AddParam(GSText(GSText.STR_NEIGHBOUR_GROWTH_INFO));			
		}
		if (GSController.GetSetting("enable_stockpiles") == 1) {
			// Add stockpile Info
			local stockpile_info = GSText(GSText.STR_0_TOWN_GOAL_STOCKPILE_INFO_GUI + this.town_effect_cargos.len());
			foreach(cargo_effect_type, cargo_list in this.town_effect_cargos) {
				local stockpile = this.cargo_stockpile.rawget(cargo_effect_type);
				// While it would be desirable to switch to {NUM} {CARGO_LIST} if > 1 cargo
				// is used, it needs too many string parameters. (exceeding the 20 parameters limit)
				// So only the first cargo name is displayed while the amount is actually the
				// total of all cargoes.
				stockpile_info.AddParam(cargo_list[0]);
				stockpile_info.AddParam(stockpile);
				local delivery_goal = this.cargo_delivery_goals.rawget(cargo_effect_type);
				local limit = this.GetStockpileMaxLimit(cargo_effect_type);
				assert(limit > 0);
				local ratio = stockpile*100/limit;
				Log.Info(GSTown.GetName(this.id) + " [" + cargo_effect_type + "] cargo ratio: " +
						stockpile + "/" + limit + " = " + ratio, Log.LVL_DEBUG);
				stockpile_info.AddParam(ratio);
			}
			text.AddParam(stockpile_info);
		} else {
			text.AddParam("");
		}
	}

	GSTown.SetText(this.id, text);
}

function GoalTown::IsManualGrowthControlEnabled()
{
	local town_growth_toggle_method = GSController.GetSetting("town_growth_toggle_method");
	local growth_enabled = town_growth_toggle_method == GROWTH_TOGGLE_ENABLED_DEFAULT_TO_ON;

	Log.Info(GSTown.GetName(this.id) + " - 1 Growth: " + growth_enabled);

	for (local companyID = GSCompany.COMPANY_FIRST; companyID <= GSCompany.COMPANY_LAST; companyID++) {
		if (GSCompany.ResolveCompanyID(companyID) != GSCompany.COMPANY_INVALID) {
			local cm = GSCompanyMode(companyID);
			local sign_list = GSSignList();
			// Only look at signs at town tile
			sign_list.Valuate(GSSign.GetLocation);
			sign_list.KeepValue(GSTown.GetLocation(this.id));
			// Filter out Deity signs
			sign_list.Valuate(GSSign.GetOwner);
			sign_list.KeepValue(companyID);
			foreach(s, _ in sign_list) {
				local lname = GSSign.GetName(s).tolower();
				if (lname == "on") growth_enabled = true;
				else if (lname == "off") growth_enabled = false;
			}
		}
	}

	Log.Info(GSTown.GetName(this.id) + " - 2 Growth: " + growth_enabled);

	return growth_enabled;
}
function DisableGrowth(town_id)
{
	if ("TOWN_GROWTH_NONE" in GSTown) { // on 1.4+ use special value that tell OpenTTD to stop growth completely
		GSTown.SetGrowthRate(town_id, GSTown.TOWN_GROWTH_NONE);
	} else {
		GSTown.SetGrowthRate(town_id, 16 * 1000); // grow every 16 years
	}
}
function GoalTown::SetGrowthRate()
{
	local town_growth_toggle_method = GSController.GetSetting("town_growth_toggle_method");
	if (town_growth_toggle_method != GROWTH_TOGGLE_DISABLED &&
			!this.IsManualGrowthControlEnabled())
	{
		// Town growth is disabled via manual control
		Log.Info("Town growth manually disabled in " + GSTown.GetName(this.id), Log.LVL_DEBUG);
		this.growth_manually_disabled = true;
		DisableGrowth(this.id);
		return;
	}
	this.growth_manually_disabled = false;

	local congestion_policy = GSController.GetSetting("congestion_policy");
	if(congestion_policy == CONGESTION_GROW_STOP && this.is_congested)
	{
		// Congestion stops town from growing
		Log.Info("Town growth stopped due to congestion in " + GSTown.GetName(this.id), Log.LVL_DEBUG);
		DisableGrowth(this.id);
		return;
	}

	local rating = GSTown.TOWN_RATING_NONE;
	for (local companyID = GSCompany.COMPANY_FIRST; companyID <= GSCompany.COMPANY_LAST; companyID++) {
		if (GSCompany.ResolveCompanyID(companyID) != GSCompany.COMPANY_INVALID) {
			local r = GSTown.GetRating(this.id, companyID);
			if (r > rating) rating = r;
		}
	}

	local rate = 420;
	switch (rating) {
		case GSTown.TOWN_RATING_NONE:        rate = 420; break;
		case GSTown.TOWN_RATING_APPALLING:   rate = 360; break;
		case GSTown.TOWN_RATING_VERY_POOR:   rate = 300; break;
		case GSTown.TOWN_RATING_POOR:        rate = 260; break;
		case GSTown.TOWN_RATING_MEDIOCRE:    rate = 220; break;
		case GSTown.TOWN_RATING_GOOD:        rate = 190; break;
		case GSTown.TOWN_RATING_VERY_GOOD:   rate = 160; break;
		case GSTown.TOWN_RATING_EXCELLENT:   rate = 130; break;
		case GSTown.TOWN_RATING_OUTSTANDING: rate = 100; break;
	}

	if(congestion_policy == CONGESTION_GROW_REDUCED && this.is_congested)
	{
		rate *= 4; // increase time between growth with factor 4
	}

	local town_growth_rate = GSGameSettings.GetValue("economy.town_growth_rate") - 1;
	if (town_growth_rate < 1) town_growth_rate = 1;

	rate = rate >> town_growth_rate;
	rate = rate / (GSTown.GetPopulation(this.id) / 250 + 1);

	if (rate < 1) rate = 1;
	Log.Info(GSTown.GetName(this.id) + " has growth rate: " + rate, Log.LVL_SUB_DECISIONS);
	GSTown.SetGrowthRate(this.id, rate);
}

// This is a helper for SetGoal to tidy up the code there. 
// Generally, use max() and .tointeger() manually as that gives better code and
// ensure that you only use what is really needed.
function MaxAsInt(a, b)
{
	return a > b? a.tointeger() : b.tointeger();
}

function GoalTown::SetGoal()
{
	// Check the vehicle congestion of the town
	//this.CheckCongestion(); // Called by ManageTown - the only caller of this method

	local population = GSTown.GetPopulation(this.id);
	local location = GSTown.GetLocation(this.id);

	// Neighbour factor:
	local n_percent = GSController.GetSetting("enable_neighbours") == 1?
		this.GetNeighborhoodFactor(population) : 0;
	local n_factor = n_percent > 0? n_percent / 100.0 : 1.0;

	// Difficulty factor:
	local d_percent = GSController.GetSetting("goal_scale_factor");
	local d_factor = d_percent > 0? d_percent / 100.0 : 1.0; // Use 1.0 if setting is missing

	// Compute a combined neighbour + difficulty factor
	local factor = n_factor * d_factor;

	Log.Info(GSTown.GetName(this.id) + " has overall factor " + factor, Log.LVL_DEBUG);

	switch (GSGame.GetLandscape()) {
		case GSGame.LT_TEMPERATE:
		case GSGame.LT_TOYLAND:
			this.SetCargoGoal(GSCargo.TE_PASSENGERS, MaxAsInt(((population / 10) - 5) * factor, 1));
			this.SetCargoGoal(GSCargo.TE_MAIL,       MaxAsInt(((population / 50) - 5) * factor, 0));
			this.SetCargoGoal(GSCargo.TE_GOODS,      MaxAsInt(((population / 100) - 5) * factor, 0));
			break;

		case GSGame.LT_ARCTIC:
			this.SetCargoGoal(GSCargo.TE_PASSENGERS, MaxAsInt(((population / 10) - 5) * factor, 1));
			this.SetCargoGoal(GSCargo.TE_FOOD,       MaxAsInt(((population / 20) - 5) * factor, 0));
			this.SetCargoGoal(GSCargo.TE_MAIL,       MaxAsInt(((population / 50) - 10) * factor, 0));
			this.SetCargoGoal(GSCargo.TE_GOODS,      MaxAsInt(((population / 100) - 200) * factor, 0));
			break;

		case GSGame.LT_TROPIC:
			// non-desert towns have the 'water' requirement added to the food requirement instead.
			// It will not make food requirement kick in earlier, but when it does it will grow quicker.
			local desert_town = Town.IsDesertTown(this.id);
			Log.Info(GSTown.GetName(this.id) + " at " + Tile.GetTileString(location) + " is desert: " + desert_town, Log.LVL_DEBUG);
			local water_requirement = MaxAsInt(((population / 50) - 2) * factor, 0);
			this.SetCargoGoal(GSCargo.TE_PASSENGERS, MaxAsInt(((population / 10) - 5) * factor, 1));
			this.SetCargoGoal(GSCargo.TE_FOOD,       MaxAsInt(((population / 20) - 5) * factor, 0) + (desert_town? 0 : water_requirement));
			this.SetCargoGoal(GSCargo.TE_WATER,      desert_town? water_requirement : 0);
			this.SetCargoGoal(GSCargo.TE_MAIL,       MaxAsInt(((population / 50) - 10) * factor, 0));
			this.SetCargoGoal(GSCargo.TE_GOODS,      MaxAsInt(((population / 100) - 20) * factor, 0));
			break;
	}
}

function GoalTown::SetCargoGoal(cargo_effect_type, cargo_requirement)
{
	// cargo_requirement is the amount of cargo effect type needed for town based on its population and neighborhood status
	// cargo_goal is the adjusted value based on the existing stockpile of cargo from previous over-deliveries
	local cargo_goal = cargo_requirement;

	if (GSController.GetSetting("enable_stockpiles")) {
		// Is this the first time cargo goals is set in a game loaded from a
		// save or a new game
		if (this.prev_cycle == GoalTown.CYCLE_INIT_NEW_GAME || this.prev_cycle == GoalTown.CYCLE_INIT_FROM_SAVE) {
			// When loading a save use the old delivery goal.
			// For new games, use cargo_requirement.
			if (this.prev_cycle == GoalTown.CYCLE_INIT_FROM_SAVE) {
				cargo_goal = this.cargo_delivery_goals.rawget(cargo_effect_type); 
			}
			this.cargo_last_delivery.rawset(cargo_effect_type, GSDate.GetCurrentDate());
			Log.Info(GSTown.GetName(this.id) + " [" + cargo_effect_type + "] existing cargo goal " + cargo_goal, Log.LVL_SUB_DECISIONS);

		} else {
			// Calculate leftover cargo from previous cycle
			// local cargo_received = GSTown.GetLastMonthReceived(this.id, cargo_effect_type);
			local last_cargo_delivered_date = this.cargo_last_delivery.rawget(cargo_effect_type);
			local current_date = GSDate.GetCurrentDate();
			// Need to prorate the goals based on the delivery gap (i.e. If the last cycle was 20 days ago, it is 20/30, vs. 40 days ago being 40/30)
			local delivery_date_delta = current_date - last_cargo_delivered_date;
			local t_factor = (current_date - last_cargo_delivered_date)/30.0;
			Log.Info(GSTown.GetName(this.id) + " [" + cargo_effect_type + "] cargo requirement time factor: " +
					t_factor + ", last check done: " + delivery_date_delta + " days ago", Log.LVL_DEBUG);
			
			local cargo_received = this.GetTownCargoReceivedSinceLastCycle(this.id, cargo_effect_type);
			
			local previous_cargo_goal = GSTown.GetCargoGoal(this.id, cargo_effect_type);
			Log.Info(GSTown.GetName(this.id) + " [" + cargo_effect_type + "] original previous cargo goal: " +
					previous_cargo_goal, Log.LVL_DEBUG);
			previous_cargo_goal = previous_cargo_goal > 0? max((previous_cargo_goal * t_factor).tointeger(), 1) : 0;
			Log.Info(GSTown.GetName(this.id) + " [" + cargo_effect_type + "] time-adjusted previous cargo goal: " +
					previous_cargo_goal, Log.LVL_DEBUG);
			
			// cargo_extra is the amount of cargo left after the previous cycle's goal was satisfied
			local cargo_extra = max(cargo_received - previous_cargo_goal, 0);

			Log.Info(GSTown.GetName(this.id) + " [" + cargo_effect_type + "] old cargo stockpile: " +
					this.cargo_stockpile.rawget(cargo_effect_type), Log.LVL_DEBUG);
			Log.Info(GSTown.GetName(this.id) + " [" + cargo_effect_type + "] cargo delivered: " +
					cargo_received + ", old goal: " + previous_cargo_goal + " overflow: " + cargo_extra, Log.LVL_DEBUG);
			
			// Calculate new stockpile amount, adding the leftover from recent delivery, 
			//	after satisfying the existing goal
			this.cargo_stockpile.rawset(cargo_effect_type, this.cargo_stockpile.rawget(cargo_effect_type) + cargo_extra);
			
			Log.Info(GSTown.GetName(this.id) + " [" + cargo_effect_type + "] new cargo stockpile: " +
					this.cargo_stockpile.rawget(cargo_effect_type), Log.LVL_DEBUG);

			Log.Info(GSTown.GetName(this.id) + " [" + cargo_effect_type + "] cargo new goal: " +
					cargo_requirement + ", available: " + this.cargo_stockpile.rawget(cargo_effect_type), Log.LVL_SUB_DECISIONS);
			
			// Calculating the new goal amount, when taking into account how much cargo is in stockpile
			if (this.cargo_stockpile.rawget(cargo_effect_type) > cargo_requirement) {
				this.cargo_stockpile.rawset(cargo_effect_type, this.cargo_stockpile.rawget(cargo_effect_type) - cargo_requirement);
				cargo_goal = 0;
				Log.Info(GSTown.GetName(this.id) + " [" + cargo_effect_type + "] cargo stockpile reserve used, left: " + this.cargo_stockpile.rawget(cargo_effect_type), Log.LVL_DEBUG);
			} else {
				cargo_goal = max(cargo_requirement - this.cargo_stockpile.rawget(cargo_effect_type), 0);
				this.cargo_stockpile.rawset(cargo_effect_type, 0);
				Log.Info(GSTown.GetName(this.id) + " [" + cargo_effect_type + "] cargo stockpile reserve depleted, " + cargo_goal + " is still required to be delivered", Log.LVL_DEBUG);
			}

			this.cargo_delivery_goals.rawset(cargo_effect_type, cargo_requirement);

			this.EnforceStockpileMaxLimit(cargo_effect_type, cargo_requirement);
		}
	}

	// Set town goal for cargo
	GSTown.SetCargoGoal(this.id, cargo_effect_type, cargo_goal);
}

function GoalTown::GetTownCargoReceivedSinceLastCycle(town_id, cargo_effect_type) 
{
	// Return 0 if there is no cargoes for some town effect type
	if (!this.town_effect_cargos.rawin(cargo_effect_type)) return 0;

	local amount = 0;
	local date = GSDate.GetCurrentDate();
	local cargo_list = this.town_effect_cargos.rawget(cargo_effect_type);
	local cargo_names = "";
	foreach(cargo_id in cargo_list) {
		for (local c = GSCompany.COMPANY_FIRST; c <= GSCompany.COMPANY_LAST; c++) {
			if (GSCompany.ResolveCompanyID(c) != GSCompany.COMPANY_INVALID) {
				amount += GSCargoMonitor.GetTownDeliveryAmount(c, cargo_id, town_id, true);
			}
		}
		if (cargo_names != "") cargo_names += ", ";
		cargo_names += GSCargo.GetCargoLabel(cargo_id);
	}
	Log.Info(GSTown.GetName(town_id) + " [" + cargo_effect_type + " (" + cargo_names + ")] delivered since last check " + amount, Log.LVL_SUB_DECISIONS);
	this.cargo_last_delivery.rawset(cargo_effect_type, date);
	return amount;
}

function GoalTown::GetStockpileMaxLimit(cargo_effect_type)
{
	// Allow 10 times the monthly requirement or at minimum 50 cargo items. 
	// [that much food would spoil anyways :)]
	return max(50, this.cargo_delivery_goals.rawget(cargo_effect_type) * 10);
}

function GoalTown::EnforceStockpileMaxLimit(cargo_effect_type, cargo_requirement)
{
	// If the amount of stockpiled cargo is larger than the limit,
	//	discard what's over that limit
	local limit = this.GetStockpileMaxLimit(cargo_effect_type);
	if (this.cargo_stockpile.rawget(cargo_effect_type) > limit) { 
		this.cargo_stockpile.rawset(cargo_effect_type, limit);
	}
}

function GoalTown::GetNeighborhoodFactor(self_population)
{
	local factor = 100;
	local use_percent_method = GSController.GetSetting("neighbour_compare_method") == 2;

	local c = 3; // coefficient for factor change

	foreach(n in this.neighbors)
	{
		local diff = GSTown.GetPopulation(n.id) - self_population; 
		if (use_percent_method) {
			// New method based on percentage difference
			factor -= diff * 100.0 / self_population * c;
		} else {
			// Old method based on direct population difference
			factor -= diff * c;
		}
	}

	factor = factor.tointeger();

	factor = max(factor, 70);
	factor = min(factor, 500);

	Log.Info(GSTown.GetName(this.id) + " has neighbour factor " + factor, Log.LVL_DEBUG);

	return factor;
}

function GoalTown::VehicleInRectValuator(vehicle, min_x, min_y, max_x, max_y)
{
	local loc = GSVehicle.GetLocation(vehicle);
	local x = GSMap.GetTileX(loc);
	local y = GSMap.GetTileY(loc);

	return x >= min_x && y >= min_y && x <= max_x && y <= max_y;
}
function GoalTown::CheckCongestion()
{
	local congestion_policy = GSController.GetSetting("congestion_policy");

	// don't waste time on finding out congestion if towns don't care
	if(congestion_policy == CONGESTION_DONT_CARE)
	{
		// Remove congestion sign in case the GS setting was changed in-game
		Helper.SetSign(GSTown.GetLocation(this.id), "", true);
		return; 
	}

	// Which area to consider for congestion?
	local center = GSTown.GetLocation(this.id);
	local radius = min(GSTown.GetPopulation(this.id) / 150 + 2, 8);

	local north_corner = Direction.GetTileInDirection(center, Direction.DIR_N, radius);
	local south_corner = Direction.GetTileInDirection(center, Direction.DIR_S, radius);
	local min_x = GSMap.GetTileX(north_corner);
	local min_y = GSMap.GetTileY(north_corner);
	local max_x = GSMap.GetTileX(south_corner);
	local max_y = GSMap.GetTileY(south_corner);

	local square_side = radius * 2 + 1;
	local tile_count = square_side * square_side;

	// Figure out how many road vehicles there are in the town
	local total_vehicles_count = 0;
	local companies = [];
	for(local c = GSCompany.COMPANY_FIRST; c <= GSCompany.COMPANY_LAST; c++)
	{
		if(GSCompany.ResolveCompanyID(c) == GSCompany.COMPANY_INVALID)
			continue;

		local cm = GSCompanyMode(c);

		local vehicles = GSVehicleList();
		vehicles.Valuate(GSVehicle.GetVehicleType);
		vehicles.KeepValue(GSVehicle.VT_ROAD);
		vehicles.Valuate(GoalTown.VehicleInRectValuator, min_x, min_y, max_x, max_y);
		vehicles.KeepValue(1);

		local company_count = vehicles.Count();
		if(company_count > 0)
			companies.append(c);

		total_vehicles_count += company_count;
	}

	// Is the town congested?
	local congestion_limit_factor = GSController.GetSetting("congestion_limit_factor");
	congestion_limit_factor = congestion_limit_factor > 0? congestion_limit_factor / 100.0 : 1.0;
	local congestion_limit = (min(radius * 3 + GSTown.GetPopulation(this.id) / 25, 100) * congestion_limit_factor).tointeger();
	local is_congested = total_vehicles_count > congestion_limit;

	Log.Info("Vehicles in " + GSTown.GetName(this.id) + ": " + total_vehicles_count + "   congestion limit: " + congestion_limit + "  radius: " + radius, Log.LVL_DEBUG);

	// Has the congested state changed since last check?
	if(is_congested != this.is_congested)
	{
		// Remove old goal regardless if we expect there to be any
		GSGoal.Remove(this.congestion_goal_id);
		this.congestion_goal_id = -1;

		if(is_congested)
		{
			foreach(c in companies)
			{
				if(congestion_policy == CONGESTION_GROW_REDUCED)
					GSNews.Create(GSNews.NT_GENERAL, GSText(GSText.STR_TOWN_CONGESTED_GROW_REDUCED_NEWS, this.id), c);
				else
					GSNews.Create(GSNews.NT_GENERAL, GSText(GSText.STR_TOWN_CONGESTED_GROW_STOPPED_NEWS, this.id), c);
			}

			if(congestion_policy == CONGESTION_GROW_REDUCED)
				Helper.SetSign(GSTown.GetLocation(this.id), GSText(GSText.STR_TOWN_CONGESTED_GROW_REDUCED_SIGN), true);
			else
				Helper.SetSign(GSTown.GetLocation(this.id), GSText(GSText.STR_TOWN_CONGESTED_GROW_STOPPED_SIGN), true);

			this.congestion_goal_id = GSGoal.New(GSCompany.COMPANY_INVALID, GSText(GSText.STR_REDUCE_TOWN_CONGESTION_GOAL, this.id), GSGoal.GT_TOWN, this.id);
		}
		else
		{
			Helper.SetSign(GSTown.GetLocation(this.id), "", true);
		}

		this.is_congested = is_congested;
	}

}

function GoalTown::Restore()
{
	// Set a slow growth rate so the town don't boom when the cargo goals are removed
	GSTown.SetGrowthRate(this.id, 16 * 1000);

	GSTown.SetCargoGoal(this.id, GSCargo.TE_PASSENGERS, 0);
	GSTown.SetCargoGoal(this.id, GSCargo.TE_FOOD,       0);
	GSTown.SetCargoGoal(this.id, GSCargo.TE_WATER,      0);
	GSTown.SetCargoGoal(this.id, GSCargo.TE_MAIL,       0);
	GSTown.SetCargoGoal(this.id, GSCargo.TE_GOODS,      0);

	GSTown.SetText(this.id, GSText(GSText.STR_EMPTY_TOWN_GUI));

	// On 1.4+, give growth rate control back to OpenTTD using a new flag
	if ("TOWN_GROWTH_NORMAL" in GSTown) {
		GSTown.SetGrowthRate(this.id, GSTown.TOWN_GROWTH_NORMAL);
	}

	// For 1.3:
	// Later, if 'economy.town_growth_rate' is enabled, the game will regulate the town growth back to normal.
}

function GoalTown::SaveToTable()
{
	Log.Info("Saving town " + GSTown.GetName(this.id) + ":" + this.id, Log.LVL_SUB_DECISIONS);
	if (Log.IsLevelAccepted(Log.LVL_DEBUG) && GSController.GetSetting("enable_stockpiles") == 1) {
		foreach (cargo_effect_type, amount in this.cargo_stockpile) {
			Log.Info(" -- " + cargo_effect_type + ":" + amount, Log.LVL_DEBUG);
		}
	}

	return {
		id = this.id,
		neighbors = this.neighbors,
		growth_manually_disabled = this.growth_manually_disabled,
		congestion_goal_id = this.congestion_goal_id,
		cargo_stockpile = this.cargo_stockpile,
		cargo_delivery_goals = this.cargo_delivery_goals,
	};
}
	
/* static */ function GoalTown::CreateFromTable(table, version)
{
	local result = GoalTown(table.id, table.neighbors);

	//result.neighbors = table.neighbors;
	result.growth_manually_disabled = table.growth_manually_disabled;
	result.congestion_goal_id = table.congestion_goal_id;
	result.cargo_stockpile = table.cargo_stockpile;
	result.cargo_delivery_goals = table.cargo_delivery_goals;
	result.prev_cycle = GoalTown.CYCLE_MANAGE;

	Log.Info("Loading town " + GSTown.GetName(table.id) + ":" + table.id, Log.LVL_SUB_DECISIONS);
	foreach (cargo_effect_type, amount in result.cargo_stockpile) {
		Log.Info(" -- " + cargo_effect_type + ":" + amount, Log.LVL_SUB_DECISIONS);
	}

	result.UpdateTownText();

	return result;
}
