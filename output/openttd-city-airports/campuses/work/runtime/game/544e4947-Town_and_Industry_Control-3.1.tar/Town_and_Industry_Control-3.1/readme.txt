-- Details -- 
This Game Script controls industry and town growth by requiring
industries to be served for new ones to be build. It also requires
passengers and mail to be delivered to towns in order for them to
grow. The amounts of passengers and mail to deliver for towns to
grow, and the industry serving requirments for enabling natural 
industry building can be changed with parameters.

-- Requirements --
OpenTTD 1.4 or greater. Tested with OpenTTD 1.7 and 1.7.1.

-- Parameter details --
- Towns -
1. Passengers + mail transport percentage required: [0 - 99]
This defines the mininum percentage of both passengers and mail
that must be transported in a town in order for it to grow. Set
to above 0 to enable the town growth control in the game script.

2. 100 mail counts as X passengers: [0 - 1000]
For every 100 mail you transport, the script will take that as 
being this many passengers you transported when town growth is 
calculated.

- Industries -
3. System to control industry growth: [None, Individual serving
of industries or Point-based global serving of industries]
Set to 'None' to disable industry control.

4. System 1: Percent of industries required to be served: [0 - 99]
In order for new industries to be opened naturally, this
percentage of industries must be served.

5. System 1: Percent of cargo to transport from an industry: [1 - 99]
In order for an industry to be considered served, this percentage
of the cargo production must be transported from it.

6. System 2: Reqiured score in percent of the max score: [0 - 99]
For those using the second system, this is the mininum required
score in percent of the max score that you must attain in order
for industry growth to occur. This score is the sum of all of the
industry transport percentages, where if an industry produces more 
than one cargo, each is treated as a seperate industry.
