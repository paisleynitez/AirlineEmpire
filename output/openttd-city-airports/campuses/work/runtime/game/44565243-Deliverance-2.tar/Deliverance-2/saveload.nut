


function Deliverance::Save() {

GSLog.Info("Making some notes...")

	local Save = {
	PaxoGoals = array(GSCompany.COMPANY_LAST + 1),
	MailGoals = array(GSCompany.COMPANY_LAST + 1),
	GoodGoals = array(GSCompany.COMPANY_LAST + 1),
	FoodGoals = array(GSCompany.COMPANY_LAST + 1),
	
	PaxoDone = array(GSCompany.COMPANY_LAST + 1),
	MailDone = array(GSCompany.COMPANY_LAST + 1),
	GoodDone = array(GSCompany.COMPANY_LAST + 1),
	FoodDone = array(GSCompany.COMPANY_LAST + 1),
	
	CompanyFoundingYear = array(GSCompany.COMPANY_LAST + 1),
	
	MonthChecked = 12}
	
	Save.PaxoGoals			 = PaxoGoals;
	Save.MailGoals           = MailGoals;
	Save.GoodGoals           = GoodGoals;
	Save.FoodGoals           = FoodGoals;

	Save.PaxoDone			 = PaxoDone;
	Save.MailDone         	 = MailDone;
	Save.GoodDone          	 = GoodDone;
	Save.FoodDone          	 = FoodDone;

	Save.CompanyFoundingYear = CompanyFoundingYear;

	Save.MonthChecked        = MonthChecked;


	return Save;
}

function Deliverance::Load(version, data) {

	IsLoaded = true;

	PaxoGoals			= data.PaxoGoals		;
	MailGoals           = data.MailGoals		;
	GoodGoals           = data.GoodGoals		;
	FoodGoals           = data.FoodGoals		;
	
	PaxoDone			= data.PaxoDone		;	
	MailDone            = data.MailDone		;	
	GoodDone            = data.GoodDone		;	
	FoodDone            = data.FoodDone		;	
	
	CompanyFoundingYear = data.CompanyFoundingYear		;
	
	MonthChecked        = data.MonthChecked		;
	
GSLog.Info("Game information loaded...")	

}