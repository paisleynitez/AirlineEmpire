class Deliverance extends GSController 
{
PaxoPercent = 0;
MailPercent = 0;
GoodPercent = 0;
FoodPercent = 0;

EternalLoveMode = true;
ForceGoodOff = false;
ForceFoodOff = false;

IsLoaded = false;

Paxo = null;	// keep cargo vars 4 letters long for neatness...
Mail = null;
Good = null;
Food = null;

PaxoGoals = array(GSCompany.COMPANY_LAST + 1);
MailGoals = array(GSCompany.COMPANY_LAST + 1);
GoodGoals = array(GSCompany.COMPANY_LAST + 1);
FoodGoals = array(GSCompany.COMPANY_LAST + 1);

PaxoDone = array(GSCompany.COMPANY_LAST + 1);
MailDone = array(GSCompany.COMPANY_LAST + 1);
GoodDone = array(GSCompany.COMPANY_LAST + 1);
FoodDone = array(GSCompany.COMPANY_LAST + 1);

CompanyFoundingYear = array(GSCompany.COMPANY_LAST + 1);

MonthChecked = 12;

}

require("saveload.nut");
require("storybook.nut");

// ================= Let's go! ====================


function Deliverance::Start()
{
	GSController.Sleep(1);
	GSLog.Info("Deliverance Game Script started!");
	
	Paxo = FindCargo("PASS");
	Mail = FindCargo("MAIL");
	Good = FindCargo("GOOD");
	Food = FindCargo("FOOD");
	
	EternalLoveMode = GSController.GetSetting("EternalLoveMode");
	
// main loop ========================================

	while (true) {

	CheckCompanies();
		
	if (EternalLoveMode) {
	EternalLove();  // run the Eternal Love script to set all town ratings to Outstanding
	}
	
	GSController.Sleep(20);
	}
}


// Eternal Love script originally by jfs / nielsm / Niels Martin Hansen. Thanks!
// =============================================================================
function Deliverance::EternalLove()
{
		// Go over all towns
		local towns = GSTownList();
		for (local t = towns.Begin(); !towns.IsEnd(); t = towns.Next()) {
			// And all companies
			for (local c = GSCompany.COMPANY_FIRST; c <= GSCompany.COMPANY_LAST; c++) {
				if (!GSTown.IsValidTown(t)) break; // skip if town has disappeared
				if (GSCompany.ResolveCompanyID(c) != c) continue; // skip non-existing companies
				local cur_rating_class = GSTown.GetRating(t, c);
				// Check if rating needs to be changed
				if (cur_rating_class == GSTown.TOWN_RATING_NONE) continue;
				if (cur_rating_class == GSTown.TOWN_RATING_INVALID) continue;
				if (cur_rating_class == GSTown.TOWN_RATING_OUTSTANDING) continue;
				// It does, boost to max
				GSTown.ChangeRating(t, c, 2000);
			}
		}
}

// Find Cargo by Label
// =============================================================================

function Deliverance::FindCargo(label) {

local clist = GSCargoList();

 foreach (cargo, z in clist) {
 if (GSCargo.GetCargoLabel(cargo) == label) {
 return cargo;
 } 
 }
return null;
 }
 
// Get World Population
// =============================================================================

function Deliverance::WorldPop() {

	local pop = 0;
	local townlist = GSTownList();
	
	foreach(town, z in townlist) {
		pop = pop + GSTown.GetPopulation(town);
	}
	
	GSLog.Info("Current world population is " + pop + ".");
	
	return pop;
}

// Check Cargo Transported Last Month
// =============================================================================


function Deliverance::LastMonthTransported(company, cargo) {

	local transported = 0;
	local townlist = GSTownList();
	
	foreach(town, z in townlist) {
		transported = transported + GSCargoMonitor.GetTownDeliveryAmount(company, cargo, town, true);
	}
	
	GSLog.Info(GSCompany.GetName(company) + " transported " + transported + " " + GSCargo.GetName(cargo) + " last month.");
	
	return transported;
}