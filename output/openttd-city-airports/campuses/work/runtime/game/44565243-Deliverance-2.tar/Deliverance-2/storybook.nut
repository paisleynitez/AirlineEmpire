

// ==============================================================
function Deliverance::WriteABook(c)
{ 
GSLog.Info("Creating a new storybook for new company " + c + ".");

	CompanyFoundingYear[c] = GSDate.GetYear(GSDate.GetCurrentDate()); // record the year the company was founded

	local NewPage = GSStoryPage.New(c, GSText(GSText.STR_TITLE));
	
	// intro text 1
	
	local text;
	
	local townlist = GSTownList();
	townlist.Valuate(GSTown.GetPopulation);
	local bigtown = townlist.Begin();
	
	GSViewport.ScrollCompanyClientsTo(c, GSTown.GetLocation(bigtown));
	
	text = GSText(GSText.STR_INTRO, bigtown);
	GSStoryPage.NewElement(NewPage,GSStoryPage.SPET_TEXT, 0, text);
	text = GSText(GSText.STR_INTRO2);	
	GSStoryPage.NewElement(NewPage,GSStoryPage.SPET_TEXT, 0, text);
	
		// pax text
		if (Paxo != null) {
			text = GSText(GSText.STR_GOALBOOK, 1 << Paxo, PaxoPercent);
			GSStoryPage.NewElement(NewPage,GSStoryPage.SPET_TEXT, 0, text);
		}
			
		// mail text
			if (Mail != null) {
			text = GSText(GSText.STR_GOALBOOK, 1 << Mail, MailPercent);
		GSStoryPage.NewElement(NewPage,GSStoryPage.SPET_TEXT, 0, text);
		}
		
		// good text
		if (Good != null && !ForceGoodOff) {
			text = GSText(GSText.STR_GOALBOOK, 1 << Good, GoodPercent);
			GSStoryPage.NewElement(NewPage,GSStoryPage.SPET_TEXT, 0, text);
		}
		
		// food text
		if (Food != null && !ForceFoodOff) {
			text = GSText(GSText.STR_GOALBOOK, 1 << Food, FoodPercent);
			GSStoryPage.NewElement(NewPage,GSStoryPage.SPET_TEXT, 0, text);
		}
		
		text = GSText(GSText.STR_INTRO3, bigtown);
		GSStoryPage.NewElement(NewPage,GSStoryPage.SPET_TEXT, 0, text);
	
	GSStoryPage.Show(NewPage); // display the page
}
// ==============================================================
// Add a new storybook page when a goal is achieved

function Deliverance::WriteAPage(c, cargo, amt) 
{
	local GoalsToComplete = 4;
	if (Good == null || ForceGoodOff) { GoalsToComplete --; }
	if (Food == null || ForceFoodOff) { GoalsToComplete --; }
	
	local GoalsCompleted = 0;
	
	if (PaxoDone[c]) { GoalsCompleted ++; }
	if (MailDone[c]) { GoalsCompleted ++; }
	if (GoodDone[c]) { GoalsCompleted ++; }
	if (FoodDone[c]) { GoalsCompleted ++; }
	
	GSLog.Info("Goals Completed: " + GoalsCompleted + " of " + GoalsToComplete);
	
	GoalsToComplete = GoalsToComplete - GoalsCompleted;
	
// -

	local NewPage;
	local text;
	local years = GSDate.GetYear(GSDate.GetCurrentDate()) - CompanyFoundingYear[c];

	// set title

	if (GoalsToComplete == 0) { NewPage = GSStoryPage.New(c, GSText(GSText.STR_TIT_ACH2));} else { NewPage = GSStoryPage.New(c, GSText(GSText.STR_TIT_ACH)); }
	
	// first part - first, middle or last?
	
		 if (GoalsCompleted == 1)   {	text = GSText(GSText.STR_COMP_1, cargo, amt); }
	else if (GoalsToComplete == 0)  {	text = GSText(GSText.STR_COMP_3, cargo, amt); }
	else							{	text = GSText(GSText.STR_COMP_2, cargo, amt); }
	
		GSStoryPage.NewElement(NewPage,GSStoryPage.SPET_TEXT, 0, text);
	
	// second part - how long?
	
		 if (years < 2)   			{	text = GSText(GSText.STR_YEARS_0); }
	else if (years < 10) 			{	text = GSText(GSText.STR_YEARS_1, years); }
	else if (years < 50) 			{	text = GSText(GSText.STR_YEARS_2, years); }	
	else							{	text = GSText(GSText.STR_YEARS_3, years); }
	
		GSStoryPage.NewElement(NewPage,GSStoryPage.SPET_TEXT, 0, text);	
	
	// final part - how many goals to go?
	
	local cargo1;
	local cargo2;

		if (GoalsToComplete == 0)	{
										text = GSText(GSText.STR_NEXT_4); }
	
   else if (GoalsToComplete == 1)	{
										// which goal is missing?
										if (!PaxoDone[c]) { cargo1 = Paxo; }
								   else if (!MailDone[c]) { cargo1 = Mail; }
								   else if (!GoodDone[c] && !(Good == null || ForceGoodOff)) { cargo1 = Good; }
																						else { cargo1 = Food; }		
										text = GSText(GSText.STR_NEXT_3, 1 << cargo1); }
   else if (GoalsCompleted == 1)	{
										// which goal is next?
										if (!PaxoDone[c]) { cargo1 = Paxo; }
								   else if (!MailDone[c]) { cargo1 = Mail; }
								   else if (!GoodDone[c] && !(Good == null || ForceGoodOff)) { cargo1 = Good; }
																						else { cargo1 = Food; }		
										text = GSText(GSText.STR_NEXT_1, 1 << cargo1, 1 << cargo); }	
		else						{
										// which goals are missing?
										if (!PaxoDone[c]) { cargo1 = Paxo; }
								   else if (!MailDone[c]) { cargo1 = Mail; }
																						else { cargo1 = Good; }	

									    if (!MailDone[c] && cargo1 != Mail) { cargo2 = Mail; }
								   else if (!GoodDone[c] && !(Good == null || ForceGoodOff) && cargo1 != Good) { cargo2 = Good; }
																										  else { cargo2 = Food; }	

																						
										text = GSText(GSText.STR_NEXT_2, 1 << cargo1, 1 << cargo2); }
	
	
	
	
		GSStoryPage.NewElement(NewPage,GSStoryPage.SPET_TEXT, 0, text);		
	
	GSStoryPage.Show(NewPage); // display the page
}

// ==============================================================
function Deliverance::BurnABook(c)
{ 
	local BookList = GSStoryPageList(c);
		foreach (Page, z in BookList) {
			GSStoryPage.Remove(Page);		// Delete pages of an old book
		}
}

// ==============================================================

function Deliverance::CheckCompanies()
{
	local UpdateDay = false;
	local ThisMonth = GSDate.GetMonth(GSDate.GetCurrentDate());
	
	PaxoPercent 	= GSController.GetSetting("PaxoPercent");
	MailPercent 	= GSController.GetSetting("MailPercent");
	GoodPercent 	= GSController.GetSetting("GoodPercent");
	FoodPercent 	= GSController.GetSetting("FoodPercent");
	
	ForceGoodOff 	= !GSController.GetSetting("ForceGoodOff");	
	ForceFoodOff 	= !GSController.GetSetting("ForceFoodOff");	
		
	if (MonthChecked != ThisMonth) {
		GSLog.Info("It's Update Day!")
		MonthChecked = ThisMonth;
		UpdateDay = true;
	}

	for(local c = GSCompany.COMPANY_FIRST; c <= GSCompany.COMPANY_LAST; c++) {
		if (GSCompany.ResolveCompanyID(c) != GSCompany.COMPANY_INVALID)
		{
			local NewCompany = false;
		
			if (PaxoGoals[c] == null) // create new goals
			{
				GSLog.Info("Creating books for new company " + c + ".");
				NewCompany = true;
			
			local text = null;	
			local NewGoal = null;
			
				text = GSText(GSText.STR_GOAL_W, 0, 1, Paxo, 2, GSText(GSText.STR_LM));
				NewGoal = GSGoal.New(c,text,GSGoal.GT_NONE,0);
				PaxoGoals[c] = NewGoal;
				
				text = GSText(GSText.STR_GOAL_W, 0, 1, Mail, 2, GSText(GSText.STR_LM));
				NewGoal = GSGoal.New(c,text,GSGoal.GT_NONE,0);
				MailGoals[c] = NewGoal;	
				
			if (Good != null && !ForceGoodOff) {
				text = GSText(GSText.STR_GOAL_W, 0, 1, Good, 2, GSText(GSText.STR_LM));
				NewGoal = GSGoal.New(c,text,GSGoal.GT_NONE,0);
				GoodGoals[c] = NewGoal;	
				}
			if (Food != null && !ForceFoodOff) {	
				text = GSText(GSText.STR_GOAL_W, 0, 1, Food, 2, GSText(GSText.STR_LM));
				NewGoal = GSGoal.New(c,text,GSGoal.GT_NONE,0);
				FoodGoals[c] = NewGoal;	
				}

				GSLog.Info("Company " + c + " goals:" + PaxoGoals[c] + " " + MailGoals[c] + " " + GoodGoals[c] + " " + FoodGoals[c] +".");

				
			PaxoDone[c] = false; // wipe the goal achievement from the table
			MailDone[c] = false; // wipe the goal achievement from the table
			GoodDone[c] = false; // wipe the goal achievement from the table
			FoodDone[c] = false; // wipe the goal achievement from the table
					
					
			WriteABook(c); // Create the storybook for the new company
				
			}
			
			if 	(UpdateDay || NewCompany) { DoUpdate(c); }
		
			
		} else {
			if (PaxoGoals[c] != null) // we have goals for a company that no longer exists, so wipe them
			{		
				GSLog.Info("Burning the books of deleted company " + c + ".");
			
				GSGoal.Remove(PaxoGoals[c]);
				GSGoal.Remove(MailGoals[c]);
				GSGoal.Remove(GoodGoals[c]);
				GSGoal.Remove(FoodGoals[c]);
				
				PaxoGoals[c] = null; // wipe the goal ID from the table
				MailGoals[c] = null; // wipe the goal ID from the table
				GoodGoals[c] = null; // wipe the goal ID from the table
				FoodGoals[c] = null; // wipe the goal ID from the table
				
				PaxoDone[c] = false; // wipe the goal achievement from the table
				MailDone[c] = false; // wipe the goal achievement from the table
				GoodDone[c] = false; // wipe the goal achievement from the table
				FoodDone[c] = false; // wipe the goal achievement from the table				
				
				BurnABook(c);				
			}		
		}
	}	
}


// ==============================================================

function Deliverance::DoUpdate(c)
{
	
	local pop = WorldPop();
	local text = null;	

	// Get the stats in
	
	local PaxoTrans  = 0;
	local PaxoTargt  = 0;
	local PaxoPcenT  = 0;
				
	local MailTrans  = 0;
	local MailTargt  = 0;
	local MailPcenT  = 0;
				
	local GoodTrans  = 0;
	local GoodTargt  = 0;
	local GoodPcenT  = 0;
				
	local FoodTrans  = 0;
	local FoodTargt  = 0;
	local FoodPcenT	 = 0;
	
	
	
	
	PaxoTrans = LastMonthTransported(c, Paxo);
	PaxoTargt = pop / 100 * PaxoPercent;
	if (PaxoTargt == 0) {PaxoTargt = 1;} // div by 0 protection, if world population is < 100	
	PaxoPcenT = PaxoTrans * 100 / PaxoTargt;
	
	MailTrans = LastMonthTransported(c, Mail);
	MailTargt = pop / 100 * MailPercent;
	if (MailTargt == 0) {MailTargt = 1;} // div by 0 protection, if world population is < 100	
	MailPcenT = MailTrans * 100 / MailTargt;			

	if (Good != null && !ForceGoodOff) {	
	GoodTrans = LastMonthTransported(c, Good);
	GoodTargt = pop / 100 * GoodPercent;
	if (GoodTargt == 0) {GoodTargt = 1;} // div by 0 protection, if world population is < 100	
	GoodPcenT = GoodTrans * 100 / GoodTargt;
	}
	
	if (Food != null && !ForceFoodOff) {	
	FoodTrans = LastMonthTransported(c, Food);
	FoodTargt = pop / 100 * FoodPercent;
	if (FoodTargt == 0) {FoodTargt = 1;} // div by 0 protection, if world population is < 100
	FoodPcenT = FoodTrans * 100 / FoodTargt;		
	}
		
	// Check for Goals to mark completed
	
	if ((!PaxoDone[c] && PaxoPcenT >= 100) && // Pax is ready to complete
		!(MailDone[c] && MailPcenT < 100)  &&
		!(GoodDone[c] && GoodPcenT < 100)  &&
		!(FoodDone[c] && FoodPcenT < 100))
		{
			PaxoDone[c] = true;
			WriteAPage(c, Paxo, PaxoTrans);
		}
		
	if ((!MailDone[c] && MailPcenT >= 100) && // Pax is ready to complete
		!(PaxoDone[c] && PaxoPcenT < 100)  &&
		!(GoodDone[c] && GoodPcenT < 100)  &&
		!(FoodDone[c] && FoodPcenT < 100))
		{
			MailDone[c] = true;
			WriteAPage(c, Mail, MailTrans);
		}

	if ((Good != null && !ForceGoodOff && !GoodDone[c] && GoodPcenT >= 100) && // Pax is ready to complete
		!(MailDone[c] && MailPcenT < 100)  &&
		!(PaxoDone[c] && PaxoPcenT < 100)  &&
		!(FoodDone[c] && FoodPcenT < 100))
		{
			GoodDone[c] = true;
			WriteAPage(c, Good, GoodTrans);
		}
		
	if ((Food != null && !ForceFoodOff && !FoodDone[c] && FoodPcenT >= 100) && // Pax is ready to complete
		!(MailDone[c] && MailPcenT < 100)  &&
		!(GoodDone[c] && GoodPcenT < 100)  &&
		!(PaxoDone[c] && PaxoPcenT < 100))
		{
			FoodDone[c] = true;
			WriteAPage(c, Food, FoodTrans);
		}		
			
	// --
	// Update goal for Paxo			
	
	 if ( PaxoDone[c] && PaxoPcenT >= 100) { text = GSText(GSText.STR_GOAL_G, PaxoPcenT, PaxoTrans, Paxo, PaxoTargt, GSText(GSText.STR_LM)); }
else if	( PaxoDone[c] && PaxoPcenT < 100)  { text = GSText(GSText.STR_GOAL_X, PaxoPcenT, PaxoTrans, Paxo, PaxoTargt, GSText(GSText.STR_LM)); }
else if	(!PaxoDone[c] && PaxoPcenT >= 100) { text = GSText(GSText.STR_GOAL_O, PaxoPcenT, PaxoTrans, Paxo, PaxoTargt, GSText(GSText.STR_LM)); }
else								       { text = GSText(GSText.STR_GOAL_W, PaxoPcenT, PaxoTrans, Paxo, PaxoTargt, GSText(GSText.STR_LM)); }
	GSGoal.SetText(PaxoGoals[c], text);
	
	// Update goal for Mail
	
	 if ( MailDone[c] && MailPcenT >= 100) { text = GSText(GSText.STR_GOAL_G, MailPcenT, MailTrans, Mail, MailTargt, GSText(GSText.STR_LM)); }
else if	( MailDone[c] && MailPcenT < 100)  { text = GSText(GSText.STR_GOAL_X, MailPcenT, MailTrans, Mail, MailTargt, GSText(GSText.STR_LM)); }
else if	(!MailDone[c] && MailPcenT >= 100) { text = GSText(GSText.STR_GOAL_O, MailPcenT, MailTrans, Mail, MailTargt, GSText(GSText.STR_LM)); }
else								       { text = GSText(GSText.STR_GOAL_W, MailPcenT, MailTrans, Mail, MailTargt, GSText(GSText.STR_LM)); }
	GSGoal.SetText(MailGoals[c], text);		
	
	// Update goal for Good
	if (Good != null && !ForceGoodOff) {			
		if ( GoodDone[c] && GoodPcenT >= 100) { text = GSText(GSText.STR_GOAL_G, GoodPcenT, GoodTrans, Good, GoodTargt, GSText(GSText.STR_LM)); }
   else if ( GoodDone[c] && GoodPcenT < 100)  { text = GSText(GSText.STR_GOAL_X, GoodPcenT, GoodTrans, Good, GoodTargt, GSText(GSText.STR_LM)); }
   else if (!GoodDone[c] && GoodPcenT >= 100) { text = GSText(GSText.STR_GOAL_O, GoodPcenT, GoodTrans, Good, GoodTargt, GSText(GSText.STR_LM)); }
	else								       { text = GSText(GSText.STR_GOAL_W, GoodPcenT, GoodTrans, Good, GoodTargt, GSText(GSText.STR_LM)); }
		GSGoal.SetText(GoodGoals[c], text);	
		}

	// Update goal for Food
	if (Food != null && !ForceFoodOff) {			
		if ( FoodDone[c] && FoodPcenT >= 100) { text = GSText(GSText.STR_GOAL_G, FoodPcenT, FoodTrans, Food, FoodTargt, GSText(GSText.STR_LM)); }
   else if ( FoodDone[c] && FoodPcenT < 100)  { text = GSText(GSText.STR_GOAL_X, FoodPcenT, FoodTrans, Food, FoodTargt, GSText(GSText.STR_LM)); }
   else if (!FoodDone[c] && FoodPcenT >= 100) { text = GSText(GSText.STR_GOAL_O, FoodPcenT, FoodTrans, Food, FoodTargt, GSText(GSText.STR_LM)); }
	else								       { text = GSText(GSText.STR_GOAL_W, FoodPcenT, FoodTrans, Food, FoodTargt, GSText(GSText.STR_LM)); }
		GSGoal.SetText(FoodGoals[c], text);	
		}
}