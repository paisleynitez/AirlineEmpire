
class Deliverance extends GSInfo {
	function GetAuthor()		{ return "Pikka"; }
	function GetName()			{ return "Deliverance"; }
	function GetDescription() 	{ return ""; }
	function GetVersion()		{ return 2; }
	function GetDate()			{ return "2022-2-1"; }
	function CreateInstance()	{ return "Deliverance"; }
	function GetShortName()		{ return "DVRC"; } // Replace this with your own unique 4 letter string
	function GetAPIVersion()	{ return "12"; }

	function GetSettings() {
	
			AddSetting({name = "EternalLoveMode", 
				description = "'Eternal Love' mode - permanently set all town ratings to Outstanding", 
				easy_value = 1, 
				medium_value = 1, 
				hard_value = 1, 
				custom_value = 1, 
				flags = CONFIG_BOOLEAN});
				
		AddSetting({name = "PaxoPercent", 
				description = "The percentage of the population which must be transported in a month to win the game", 
				easy_value = 5, 
				medium_value = 5, 
				hard_value = 5, 
				custom_value = 5, 
				flags = CONFIG_INGAME, min_value = 1, max_value = 50});	
	
		AddSetting({name = "MailPercent", 
				description = "The equivalent percentage of mail", 
				easy_value = 3, 
				medium_value = 3, 
				hard_value = 3, 
				custom_value = 3, 
				flags = CONFIG_INGAME, min_value = 1, max_value = 50});	
				
		AddSetting({name = "GoodPercent", 
				description = "The equivalent percentage of goods, if available", 
				easy_value = 5, 
				medium_value = 5, 
				hard_value = 5, 
				custom_value = 5, 
				flags = CONFIG_INGAME, min_value = 1, max_value = 50});	

		AddSetting({name = "FoodPercent", 
				description = "The equivalent percentage of food, if available", 
				easy_value = 5, 
				medium_value = 5, 
				hard_value = 5, 
				custom_value = 5, 
				flags = CONFIG_INGAME, min_value = 1, max_value = 50});		

			AddSetting({name = "ForceGoodOff", 
				description = "Turn off to disable Goods, if the automatic detection doesn't work (or you just don't want to transport it)", 
				easy_value = 1, 
				medium_value = 1, 
				hard_value = 1, 
				custom_value = 1, 
				flags = CONFIG_BOOLEAN});
				
			AddSetting({name = "ForceFoodOff", 
				description = "Turn off to disable Food, if the automatic detection doesn't work (or you just don't want to transport it)", 
				easy_value = 1, 
				medium_value = 1, 
				hard_value = 1, 
				custom_value = 1, 
				flags = CONFIG_BOOLEAN});				
				
	}
}

RegisterGS(Deliverance());
