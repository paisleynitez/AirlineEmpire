class DumbAI extends AIInfo 
{
  function GetAuthor()        { return "Noobish AI Builder DrReVaN"; }
  function GetName()          { return "DumbAI"; }
  function GetDescription()   { return "My first try building an AI for OpenTTD. Currently transports every cargo except Passangers, Mail, Value and Goods. Uses Trucks only."; }
  function GetVersion()       { return 1; }
  function MinVersionToLoad() { return 1; }
  function GetDate()          { return "2018-02-08"; }
  function GetShortName()     { return "DuAI"; }
  function CreateInstance()   { return "DumbAI"; }
  function GetAPIVersion()    { return "1.0"; }
}

RegisterAI(DumbAI());