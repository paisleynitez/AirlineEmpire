/* -*- Mode: C++; tab-width: 6 -*- */
/*
 *
 * This file is part of ToyLib a library for OpenTTD noai and nogo
 * Copyright (C) 2014 Krinn <krinn@chez.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

require("version.nut");
class AIToyLib extends AILibrary {
	function GetAuthor()		{ return "Krinn"; }
	function GetName()			{ return "AIToyLib v2"; }
	function GetShortName()		{ return "TLAI"; }
	function GetDescription()	{ return "Library that provide funds to toy AIs from a GS (updated by Firrel)."; }
	function GetAPIVersion()	{ return "14"; }
	function GetVersion()		{ return AITOYLIB_VERSION; }
	function GetDate()			{ return "2024-10-06"; }
	function GetURL()			{ return "http://www.tt-forums.net/viewtopic.php?f=65&t=71597"; }
	function CreateInstance()	{ return "AIToyLib"; }
	function GetCategory()		{ return "Library"; }
}

RegisterLibrary(AIToyLib());
