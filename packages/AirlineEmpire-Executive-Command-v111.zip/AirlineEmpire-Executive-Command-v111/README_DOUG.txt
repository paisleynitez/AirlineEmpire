AIRLINE EMPIRE - EXECUTIVE COMMAND v1.1.11
Overwrite-ready package for Doug
Prepared: 2026-08-18

EXPECTED BASELINE
Branch: doug/v1.1.11-baseline
Commit: d078921a2a0b6861686ac2a7a2dba72399a4ee28
Package version: 1.1.11

HOW TO APPLY
1. Keep this entire extracted folder together. Do not move files out of payload.
2. Place/extract the folder anywhere inside C:\GitHub\AirlineEmpire (the packages folder is fine).
3. Double-click APPLY_PATCH.bat.
4. Read the validation results. The window stays open on success or failure.

If the package is stored outside the repository, drag the C:\GitHub\AirlineEmpire folder onto APPLY_PATCH.bat.

SAFETY BEHAVIOR
- Validates the AirlineEmpire package name and version.
- Validates the exact Git branch and commit using read-only Git commands.
- Validates every payload hash and every destination baseline hash before writing.
- Creates missing destination folders.
- Accepts an already-applied package without rewriting it.
- Stops before any overwrite if a branch, commit, version, file, or hash is unexpected.
- Stages all replacements, keeps temporary backups, verifies final hashes, and restores originals if an overwrite step fails.
- Shows success/failure and keeps the window open.
- Does not commit, push, merge, reset, switch branches, or discard unrelated files.

PROJECT-RELATIVE FILES INSTALLED
game/index.html
game/css/executive-command-v111.css
docs/qa.md
docs/implementation_executive_command_theme_v111.md
docs/qa_executive_command_theme_v111.md
tests/executive-command-theme.test.cjs

WHAT CHANGED
- Applies the approved Style 1 Executive Command dark-glass treatment to the Operations Center dashboard.
- Applies the same system to shared and named submenu/modal surfaces.
- Preserves the modular loader, gameplay code, data, save schema, layouts, and original artwork.
- Adds implementation documentation, QA/test documentation, and automated theme guards.

VERIFICATION AT PACKAGE BUILD
- npm.cmd test: 8/8 passed.
- npm.cmd run build: passed.
- Live Vite loader and theme endpoints: HTTP 200.
- Browser automation visual inspection: not completed because the installed browser service failed its trusted-code-path check. This limitation is recorded in docs/qa_executive_command_theme_v111.md.
