param(
    [string]$RepoRoot
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Write-Step([string]$Message) {
    Write-Host "[CHECK] $Message" -ForegroundColor Cyan
}

function Write-Pass([string]$Message) {
    Write-Host "[PASS]  $Message" -ForegroundColor Green
}

function Stop-Patch([string]$Message) {
    throw $Message
}

function Resolve-Repository([string]$Requested, [string]$PackageRoot) {
    if ($Requested) {
        return [IO.Path]::GetFullPath($Requested)
    }

    $candidate = [IO.Path]::GetFullPath($PackageRoot)
    for ($depth = 0; $depth -le 4; $depth++) {
        if ((Test-Path -LiteralPath (Join-Path $candidate 'package.json')) -and
            (Test-Path -LiteralPath (Join-Path $candidate 'game\index.html'))) {
            return $candidate
        }
        $parent = Split-Path -Parent $candidate
        if (-not $parent -or $parent -eq $candidate) { break }
        $candidate = $parent
    }

    Stop-Patch 'Could not locate the AirlineEmpire repository. Extract this package inside the repository, or drag the repository folder onto APPLY_PATCH.bat.'
}

function Invoke-ReadOnlyGit([string]$Root, [string[]]$Arguments) {
    $rootUnix = $Root.Replace('\', '/')
    $result = & git -c "safe.directory=$rootUnix" -C $Root @Arguments 2>&1
    if ($LASTEXITCODE -ne 0) {
        Stop-Patch "Git validation failed: $($result -join [Environment]::NewLine)"
    }
    return (($result | Out-String).Trim())
}

$packageRoot = Split-Path -Parent $PSCommandPath
$manifestPath = Join-Path $packageRoot 'PATCH_MANIFEST.json'
$payloadRoot = Join-Path $packageRoot 'payload'
$backupRoot = $null
$stagedFiles = [System.Collections.Generic.List[string]]::new()
$backupRecords = [System.Collections.Generic.List[object]]::new()
$writeStarted = $false
$completed = $false

try {
    Write-Step 'Locating repository and reading package manifest.'
    if (-not (Test-Path -LiteralPath $manifestPath)) { Stop-Patch 'PATCH_MANIFEST.json is missing.' }
    if (-not (Test-Path -LiteralPath $payloadRoot)) { Stop-Patch 'The payload folder is missing.' }

    $manifest = Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json
    $RepoRoot = Resolve-Repository -Requested $RepoRoot -PackageRoot $packageRoot
    $RepoRoot = [IO.Path]::GetFullPath($RepoRoot).TrimEnd('\')
    Write-Pass "Repository: $RepoRoot"

    $packageJsonPath = Join-Path $RepoRoot 'package.json'
    if (-not (Test-Path -LiteralPath $packageJsonPath)) { Stop-Patch 'package.json is missing from the selected repository.' }
    $packageJson = Get-Content -Raw -LiteralPath $packageJsonPath | ConvertFrom-Json
    if ($packageJson.name -ne $manifest.expectedPackageName) {
        Stop-Patch "Repository mismatch. Expected package '$($manifest.expectedPackageName)', found '$($packageJson.name)'."
    }
    if ($packageJson.version -ne $manifest.expectedVersion) {
        Stop-Patch "Version mismatch. Expected $($manifest.expectedVersion), found $($packageJson.version)."
    }
    Write-Pass "Package identity: $($packageJson.name) $($packageJson.version)"

    if (-not (Get-Command git -ErrorAction SilentlyContinue)) { Stop-Patch 'Git is required for read-only branch and commit validation.' }
    $branch = Invoke-ReadOnlyGit -Root $RepoRoot -Arguments @('branch', '--show-current')
    $commit = Invoke-ReadOnlyGit -Root $RepoRoot -Arguments @('rev-parse', 'HEAD')
    if ($branch -ne $manifest.expectedBranch) {
        Stop-Patch "Branch mismatch. Expected '$($manifest.expectedBranch)', found '$branch'. No files were changed."
    }
    if ($commit -ne $manifest.expectedCommit) {
        Stop-Patch "Commit mismatch. Expected '$($manifest.expectedCommit)', found '$commit'. No files were changed."
    }
    Write-Pass "Git baseline: $branch at $commit"

    Write-Step 'Preflighting payload and destination hashes.'
    $updates = [System.Collections.Generic.List[object]]::new()
    foreach ($file in $manifest.files) {
        $relative = [string]$file.path
        $payload = [IO.Path]::GetFullPath((Join-Path $payloadRoot $relative))
        $destination = [IO.Path]::GetFullPath((Join-Path $RepoRoot $relative))
        $repoPrefix = $RepoRoot + [IO.Path]::DirectorySeparatorChar
        $payloadPrefix = [IO.Path]::GetFullPath($payloadRoot).TrimEnd('\') + [IO.Path]::DirectorySeparatorChar

        if (-not $destination.StartsWith($repoPrefix, [StringComparison]::OrdinalIgnoreCase)) {
            Stop-Patch "Unsafe destination path in manifest: $relative"
        }
        if (-not $payload.StartsWith($payloadPrefix, [StringComparison]::OrdinalIgnoreCase)) {
            Stop-Patch "Unsafe payload path in manifest: $relative"
        }
        if (-not (Test-Path -LiteralPath $payload -PathType Leaf)) { Stop-Patch "Payload file is missing: $relative" }

        $payloadHash = (Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash
        if ($payloadHash -ne $file.patchedSha256) { Stop-Patch "Payload integrity check failed: $relative" }

        if (Test-Path -LiteralPath $destination -PathType Leaf) {
            $destinationHash = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
            if ($destinationHash -eq $file.patchedSha256) {
                Write-Pass "Already current: $relative"
                continue
            }
            if (-not $file.originalSha256 -or $destinationHash -ne $file.originalSha256) {
                Stop-Patch "Source mismatch: $relative`nExpected the recorded baseline or already-patched file. No files were changed."
            }
        } elseif ($file.originalSha256) {
            Stop-Patch "Required baseline file is missing: $relative. No files were changed."
        }

        $updates.Add([pscustomobject]@{ Relative = $relative; Payload = $payload; Destination = $destination })
    }

    if ($updates.Count -eq 0) {
        Write-Pass 'All patch files are already current. No overwrite was needed.'
        $completed = $true
        exit 0
    }

    Write-Step "Preparing $($updates.Count) overwrite(s) transactionally."
    $backupRoot = Join-Path ([IO.Path]::GetTempPath()) ("AirlineEmpire-ExecutiveCommand-" + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
    $stageToken = '.ae-executive-command-' + [Guid]::NewGuid().ToString('N') + '.stage'

    foreach ($update in $updates) {
        $destinationDirectory = Split-Path -Parent $update.Destination
        if (-not (Test-Path -LiteralPath $destinationDirectory)) {
            New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null
        }

        $existed = Test-Path -LiteralPath $update.Destination -PathType Leaf
        $backup = Join-Path $backupRoot $update.Relative
        if ($existed) {
            $backupDirectory = Split-Path -Parent $backup
            New-Item -ItemType Directory -Path $backupDirectory -Force | Out-Null
            Copy-Item -LiteralPath $update.Destination -Destination $backup -Force
        }
        $backupRecords.Add([pscustomobject]@{ Destination = $update.Destination; Backup = $backup; Existed = $existed })

        $stage = $update.Destination + $stageToken
        Copy-Item -LiteralPath $update.Payload -Destination $stage -Force
        $stagedFiles.Add($stage)
    }

    $writeStarted = $true
    foreach ($update in $updates) {
        $stage = $update.Destination + $stageToken
        Move-Item -LiteralPath $stage -Destination $update.Destination -Force
        $stagedFiles.Remove($stage) | Out-Null
        Write-Host "[WRITE] $($update.Relative)" -ForegroundColor Yellow
    }

    foreach ($file in $manifest.files) {
        $destination = Join-Path $RepoRoot ([string]$file.path)
        $finalHash = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
        if ($finalHash -ne $file.patchedSha256) { Stop-Patch "Post-install verification failed: $($file.path)" }
    }

    $completed = $true
    Write-Pass "Executive Command v$($manifest.expectedVersion) installed and verified."
    Write-Host 'No Git commit, branch, merge, push, reset, or switch operation was performed.' -ForegroundColor Gray
    exit 0
}
catch {
    Write-Host "[FAIL]  $($_.Exception.Message)" -ForegroundColor Red

    if ($writeStarted -and $backupRecords.Count -gt 0) {
        Write-Host '[ROLLBACK] Restoring the pre-install files.' -ForegroundColor Yellow
        foreach ($record in $backupRecords) {
            try {
                if ($record.Existed) {
                    Copy-Item -LiteralPath $record.Backup -Destination $record.Destination -Force
                } elseif (Test-Path -LiteralPath $record.Destination) {
                    Remove-Item -LiteralPath $record.Destination -Force
                }
            } catch {
                Write-Host "[ROLLBACK ERROR] $($record.Destination): $($_.Exception.Message)" -ForegroundColor Red
            }
        }
    }

    exit 1
}
finally {
    foreach ($stage in $stagedFiles) {
        if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Force -ErrorAction SilentlyContinue }
    }
    if ($backupRoot -and (Test-Path -LiteralPath $backupRoot)) {
        Remove-Item -LiteralPath $backupRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
    if (-not $completed) {
        Write-Host 'Patch did not complete. Review the failure above.' -ForegroundColor Red
    }
}
