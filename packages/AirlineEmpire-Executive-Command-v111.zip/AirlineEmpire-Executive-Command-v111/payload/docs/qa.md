# QA

## Zero-warning policy

Every console warning, HTTP error, missing asset, or unexpected log message is treated as a defect until investigated, documented as technical debt, or explicitly accepted.

## Current verified snapshot — 2026-08-10

Baseline: `doug/v1.1.11-baseline` at `d078921`.

- `npm test`: 6/6 runtime smoke tests passed.
- `npm run build`: passed. Vite reports expected notices for classic scripts; the post-build copy step supplies those scripts and their runtime assets in `dist/`.
- JavaScript syntax checks passed for the changed gameplay and identity-generator files.
- Live Vite flow passed: intro/menu, New Game, scenario selection, airline founding, launch, route setup, End Turn, Continue, and Load.
- The founding picker displayed nine identities: six from the approved-250 catalog and three curated regional identities.
- The demand control was labeled as a working feature and rendered 1,146 heat circles when enabled in the test state.
- ORD–JFK opened successfully, April advanced to May 2024, and the monthly autosave restored May 2024 with $1,477M cash and one route.
- Browser logging contained only Vite connection debug messages; no warnings or errors were recorded.
- Found Airline now launches directly into the normal Operations Center flow; the removed Airline Preview / Final Review page is no longer reachable or present in the loader.
- The Launch Airline control was pressed in the live Vite build and its aircraft crossed the button before the Operations Center appeared.

## Executive Command visual system — 2026-08-18

Baseline: `doug/v1.1.11-baseline` at `d078921a2a0b6861686ac2a7a2dba72399a4ee28`.

- The approved Style 1 “Executive Command” visual system is isolated in `game/css/executive-command-v111.css` and loaded last by the modular game loader.
- Coverage includes the Operations Center dashboard, both side panels, map framing, right-side tabs, ticker, shared modal system, and named New Route, Route Manager, Fleet, Finance/Budget, City, Projects, and generated submenu surfaces.
- Theme scope is UI-only: no gameplay JavaScript, data, save schema, or simulation logic changed.
- Dedicated automated guards are in `tests/executive-command-theme.test.cjs`.
- Detailed verification is recorded in `docs/qa_executive_command_theme_v111.md`.
- `npm.cmd test` passed 8/8, the production build passed, and the live Vite loader/theme endpoints returned 200.
- In-app browser visual inspection was blocked by the installed browser service's trusted-code-path check; no screenshot or computed-style pass is claimed for this snapshot.

## Standard smoke coverage

- [x] Game starts and the main menu loads
- [x] New Game reaches the operations view
- [x] Continue and Load restore an autosave
- [x] Map and demand overlay render
- [x] Passenger route creation works
- [x] End Turn advances the month and opens the operations report
- [x] Monthly autosave preserves the advanced month and route
- [x] Browser console has no warning or error entries in the verified flow

## Remaining QA depth

The current automated suite validates loader integrity, version alignment, city/skyline parity, aircraft/visual parity, monthly-save wiring, and identity-picker asset reachability. It does not yet provide long-run balance simulations, exhaustive scenario coverage, or a broad accessibility/performance suite.

## Open QA notes

- Add a real favicon so browsers do not request a missing default icon.
- Resolve the remaining `MDE` city-alias ambiguity before enforcing unique IATA codes.
