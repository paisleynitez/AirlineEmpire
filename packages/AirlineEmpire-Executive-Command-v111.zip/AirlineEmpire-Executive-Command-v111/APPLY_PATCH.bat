@echo off
setlocal EnableExtensions
title Airline Empire - Executive Command v1.1.11 Patch
cd /d "%~dp0"

echo ============================================================
echo  AIRLINE EMPIRE - EXECUTIVE COMMAND v1.1.11
echo  Guarded overwrite installer
echo ============================================================
echo.

if "%~1"=="" (
  powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY_PATCH.ps1"
) else (
  powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY_PATCH.ps1" -RepoRoot "%~1"
)

set "PATCH_EXIT=%ERRORLEVEL%"
echo.
if "%PATCH_EXIT%"=="0" (
  echo SUCCESS: Executive Command patch completed.
) else (
  echo FAILURE: Nothing was intentionally left partially applied.
  echo Review the error above before trying again.
)
echo.
pause
exit /b %PATCH_EXIT%
